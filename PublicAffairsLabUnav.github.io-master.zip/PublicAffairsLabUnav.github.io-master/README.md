# Open Source Club Website

Uses [Hugo](https://gohugo.io/), so building should be as easy as `hugo` and dev with `hugo server`.


## Previous Sites

This site has gone through many revisions over the years.
And each time it grows larger and less maintainable.

This site recently had full rewrite, with 8916f107ad04 being the last of the "old" site.
