+++
title = "Former Officers"
description = "A list of all of the previous officers and faulty advisors that have served the Open Source Club"
+++

#### 2021-2022
* President - Dominik Winecki (winecki.1@osu.edu)
* Vice President - Adrian Vovk (vovk.5@osu.edu)
* Treasurer - Kyle Rosenberg (rosenberg.1278@osu.edu)
* Advisor - Jeremy Morris (morris.343@osu.edu)

#### 2020-2021
* President - Tom Casavant (casavant.6@osu.edu)
* Vice President - Dominik Winecki (winecki.1@osu.edu)
* Treasurer - Joshua Kingsbury (kingsbury.18@osu.edu)
* Advisor - Matt Black (black.123@osu.edu)
* Advisor - Jeremy Morris (morris.343@osu.edu)

#### 2019-2020
* President - Tom Casavant (casavant.6@osu.edu)
* Vice President - Shaffan Mustafa (mustafa.55@osu.edu)
* Treasurer - Joshua Kingsbury (kingsbury.18@osu.edu)
* System Administrator - Dominik Winecki (winecki.1@osu.edu)
* Advisor - Matt Black (black.123@osu.edu)
* Advisor - Jeremy Morris (morris.343@osu.edu)

#### Spring 2019
* President - Jack `jmoore53` Moore (moore.3337@osu.edu)
* Vice President - John `EDT` Markiewicz (markiewicz.22@osu.edu)
* Treasurer - Tom Casavant (casavant.6@osu.edu)
* Advisor - Matt Black (black.123@osu.edu)
* Advisor - Jeremy Moore (morris.343@osu.edu)

#### Fall 2018
* President - Jack `jmoore53` Moore (moore.3337@osu.edu)
* Vice President - John `EDT` Markiewicz (markiewicz.22@osu.edu)
* Treasurer - Christopher `BrainBlasted` Davis (davis.5373@osu.edu)
* Advisor - Matt Black (black.123@osu.edu)
* Advisor - Jeremy Moore (morris.343@osu.edu)

#### Spring 2018
* President - Tommy `delgeez` Delgado (delgado.78@osu.edu)
* Vice President - John `EDT` Markiewicz (markiewicz.22@osu.edu)
* Treasurer - Jack Moore (moore.3337@osu.edu)
* Librarian - Andrew `smacz` Cziryak (cziryak.1@osu.edu)
* PR Officer - Chris `brainblasted` Davis (davis.5373@osu.edu)
* Advisor - Matt Black (black.123@osu.edu)
* Advisor - Jeremy Morris (morris.343@osu.edu)

#### Fall 2017
* Benevolent Dictator - Ted Li (li.6998@osu.edu)
* Vice President - Andrew `smacz` Cziryak (cziryak.1@osu.edu)
* Treasurer - Jack Moore (moore.3337@osu.edu)
* System Administrator - John `EDT` Markiewicz (markiewicz.22@osu.edu)
* PR Officer - Tommy `delgeez` Delgado (delgado.78@osu.edu)
* Advisor - Matt Black (black.123@osu.edu)
* Advisor - Jeremy Morris (morris.343@osu.edu)

#### 2016-2017
* Benevolent Dictator - Brandon `malide` Moore (moore.3071@osu.edu)
* Vice President - Alex `aftrumpet` Fuhr (fuhr.8@osu.edu)
* Treasurer - Jack Moore (moore.3337@osu.edu)
* System Administrator - John `EDT` Markiewicz (markiewicz.22@osu.edu)
* Advisor - Matt Black (black.123@osu.edu)

#### 2015-2016
* Benevolent Dictator - Eli 'httpstr' Gladman (gladman.23@osu.edu)
* Vice President and Interim President - Alex Krieger (krieger.71@osu.edu)
* Interim Vice President - Nikit 'nefari0uss' Malkan (malkan.1@osu.edu)
* Treasurer - Brandon `riffer` Dahl (dahl.49@osu.edu)
* System Administrator - Will `LibreWulf` Osler (osler.6@osu.edu)
* Librarian - Brandon `malide` Moore (moore.3071@osu.edu)
* Advisor - Matt Black (black.123@osu.edu)

#### 2014-2015
* Benevolent Dictator - Chris `notori0us` Wallace (wallace.586@osu.edu)
* Vice President - George Kvaratkshelia (kvaratskhelia.2@osu.edu)
* Treasurer - Nikit `nefari0uss` Malkan (malkan.1@osu.edu)
* System Administrator - Will `LibreWulf` Osler (osler.6@osu.edu)
* Advisor - Shaun Rowland

#### 2013-2014
* Benevolent Dictator - Chris `notori0us` Wallace (wallace.586@osu.edu)
* Vice President - Brandon Rogers (rogers.689@osu.edu)
* Treasurer - Maxim Kim (kim.4021@osu.edu)
* Advisor - Shaun Rowland

#### 2012-2013
* President - Paul Schwendenman (schwendenman.6@osu.edu)
* Vice President and Interim President- Brad Hollander (hollander.36@osu.edu)
* Interim Vice President - Edward Powell (powell.518@osu.edu)
* Treasurer - Chris `notori0us` Wallace (wallace.586@osu.edu)
* Webmaster/Sysadmin - Brian Swaney (swaney.29@osu.edu)
* Advisor - Shaun Rowland

#### 2011-2012
* President - Daniel `paradigm` Thau (thau.4@osu.edu)
* Vice President - Paul Schwendenman (schwendenman.6@osu.edu)
* Treasurer - Joel Friedly (friedly.1@osu.edu)
* Webmaster/Sysadmin - Brian Swaney (swaney.29@osu.edu)
* Advisor - Shaun Rowland

#### 2010-2011
* President - Matt Meinwald (meinwald.1@osu.edu)
* Vice President - Daniel `paradigm` Thau (thau.4@osu.edu)
* Treasurer - Paul Schwendenman (schwendenman.6@osu.edu)
* Advisor - Shaun Rowland

#### 2009-2010
* President - Alek Rollyson
* Vice President - Matt Meinwald
* Treasurer - Dan Zeleznikar
* Advisor - Shaun Rowland

#### 2008-2009
* President - Aaron Joseph
* Vice President - Alex Lingo
* Treasurer - Silas Baronda
* E-Council rep - Peter Dietz
* Advisor - Shaun Rowland

#### 2007-2008
* President - Peter Dietz
* Vice President - Brian Swaney
* Advisor - Shaun Rowland

#### 2006-2007
* President - Alex Lingo
* Vice President - Peter Dietz
* Advisor - Shaun Rowland

#### 2005-2006
* Benevolent Dictator - Jim Dinan
* Secretary - Andrew Lathrop
* Treasurer - Alex Lingo
* Technology Coordinator - Karen Manukyan
* Advisor - Shaun Rowland

#### 2004-2005
* Benevolent Dictator - Chris Anderson
* Vice President - Ted Han

#### 2003-2004
* Benevolent Dictator - Nicholas Hurley
* Vice President - Michael Bernstein
* Treasurer - Anna Potoczny
* Secretary - Colin Walters
* Advisor - Shaun Rowland

#### 2002-2003
* Benevolent Dictator - Nicholas Hurley
* Vice President - Michael Bernstein
* Treasurer - Anna Potoczny
* Secretary - Colin Walters
* Advisor - Shaun Rowland

#### 2001-2002
* Benevolent Dictator - Isaac Jones
* Vice President - Mike Benedict
* Treasurer - Colin Walters
* Secretary - Nicholas Hurley
* Advisor - Matt Curtin

#### 2000-2001
* Benevolent Dictator - Isaac Jones
* Vice President - Mike Benedict
* Treasurer - Colin Walters
* Web Master - Tom Rosati
* Advisor - Matt Curtin

#### 1999-2000
* Benevolent Dictator - Isaac Jones
* Vice President - Mike Benedict
* Treasurer - Colin Walters
* Web Master - Tom Rosati
* Advisor - Matt Curtin
