---
date: 2011-09-29
title: Wireless Hacking
---
Thursday, September 29th at 7:00PM in Dreese Labs 266, Michael Yanovich will be covering wireless security with a heavy regard towards wireless hacking. He will be covering how wireless networks work, the several types of encryption available, and other settings that can set to try to protect your network. He will be demonstrating these attacks as well, and he encourages people to bring their laptops if they wish to participate (if your wireless card can not run the available software, he will be providing a sample dump for you to play around with, this will be available at the meeting). Everyone is encouraged to follow along and learn the most they can about wireless security.  Michael is am bringing my own equipment for demonstrative purposes and he encourage everyone to participate in the presentation.

DISCLAIMER: We do not encourage the use of any of the software and/or techniques to use be used on any equipment besides equipment that you either own or are given permission explicitly from the owner of said equipment. Also we are NOT responsible for the actions people take using these techniques learned at this meeting. All information that is being taught is very easily accessible on the Internet.
