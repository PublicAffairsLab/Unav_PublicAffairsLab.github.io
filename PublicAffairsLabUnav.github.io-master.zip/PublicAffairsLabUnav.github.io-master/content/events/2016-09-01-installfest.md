---
date: 2016-09-01
title: InstallFest
speaker: "Brandon 'Bam' Moore (malide)"
type: Meeting
---
Interested in running Linux or BSD, but haven't gotten around to installing it? Wanted to change distros, but you didn't have the time? Come to our installfest and take the time to eat some pizza and install the OS of your dreams. We'll have 5 copies of Ubuntu, 3 copies of Mint, 2 copies of Elementary, one OpenBSD stick, and one Arch ISO. If nothing strikes your fancy, we can download it! 

If you don't know what OS would best fit you, don't worry, our officers can help you decide. If you don't want to dual boot we can help you install the OS in a virtual machine.
