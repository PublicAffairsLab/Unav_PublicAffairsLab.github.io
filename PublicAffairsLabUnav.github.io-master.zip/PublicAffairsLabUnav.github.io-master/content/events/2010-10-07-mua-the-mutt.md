---
date: 2010-10-07
type: "Meeting"
title: Mua the Mutt
---
On Thursday, October 7th at 7PM in the Ohio Union Senate Chamber, Alek Rollyson will be explaining what Mutt is, what it does, and why you should care. Per Mutt's mantra, most e-mail clients suck, Mutt just sucks less. Alek will be showcasing Mutt's capabilities via the story of Mua the Mutt and the adventures in which she partakes. Through a storytelling device, he will explain that Mutt is solely a mail user agent and requires other pieces and parts in order to function as a complete email solution. Once the entire system is complete, the user will have powerful regex capabilities, email threading, offline email access, pgp encryption and signing, sending and receiving from multiple addresses, 256 color inbox sorting, and synching with gmail if one wishes. This meeting will be perfect for those who are scared of Mutt's complexity, tried Mutt and got frustrated, looking to improve their Mutt setup, or have no idea what Mutt is but want an extremely powerful and 1337 email setup.
