---
date: 2016-09-24
title: Vim vs Emacs
speaker: EDT and malide
type: Meeting
---
Join us Thursday, September 29th, at 19:00 EDT, as we talk about the storied editors that have been pitted against each other for forty years. The speed and extensible nature of these editors have made them very popular along with the ability to be ran headless unlike modern day editors. Learning one of these two editors is strongly advised in order to be effective in any environment.
