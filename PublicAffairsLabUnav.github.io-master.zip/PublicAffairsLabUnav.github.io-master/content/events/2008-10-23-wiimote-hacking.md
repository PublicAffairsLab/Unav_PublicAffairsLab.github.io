---
date: 2008-10-23
type: "Meeting"
title: Wiimote Hacking
---
This Thursday we will be taking a look at the Nintendo Wii remote (or Wiimote)
and giving a brief overview of how it works. After that we will look at some of
the Wiimote hacks that have been done by other people and hopefully come up with
an idea for a new hack that we can start working on as a club project. We will
be meeting at 7pm in [Dreese Labs](http://www.osu.edu/map/building.php?building=279) room 266.
