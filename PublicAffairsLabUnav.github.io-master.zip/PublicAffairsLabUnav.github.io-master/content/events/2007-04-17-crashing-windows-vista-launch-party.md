---
date: 2007-04-17
type: "Meeting"
title: Crashing Windows Vista Launch Party
created: 1176796022
---
On April 17<sup>th</sup> 2007, with about a couple hours' notice, some of us
gathered for an hour before the meeting to join the fun at Microsoft's Windows
Vista launch party in Dreese Labs.

<!-- FIXME -->

<!-- Some pictures below, courtesy of Alex Lingo:

[![Farhad and Alex man the booth outside the lecture hall.](/sites/default/files/Picture%20005.thumb__0.jpg)](/sites/default/files/Picture%20005_0.jpg "Farhad and Alex man the booth outside the lecture hall.")

[![Alex, Farhad, and Jim discussing the finer points of why Vista and DRM suck with a curious student.](/sites/default/files/Picture%20007.thumb_.jpg)](/sites/default/files/Picture%20007_0.jpg "Alex, Farhad, and Jim discussing the finer points of why Vista and DRM suck with a curious student.")

[![We put this on one of their pizza boxes in good-natured humor.](/sites/default/files/Picture%20008.thumb_.jpg)](/sites/default/files/Picture%20008.jpg "We put this on one of their pizza boxes in good-natured humor.")

[![We had pamphlets, buttons, stickers, and CD's.](/sites/default/files/Picture%20009.thumb_.jpg)](/sites/default/files/Picture%20009.jpg "We had pamphlets, buttons, stickers, and CD's.")

[![Closer view of the table elements.](/sites/default/files/Picture%20010.thumb_.jpg)](/sites/default/files/Picture%20010.jpg "Closer view of the table elements.")

[![Our pamplets.](/sites/default/files/Picture%20011.thumb_.jpg)](/sites/default/files/Picture%20011.jpg "Our pamplets.")

[![Pamphlet Detail.](/sites/default/files/Picture%20012.thumb_.jpg)](/sites/default/files/Picture%20012.jpg "Pamphlet Detail.")

[![Pamphlet Inside.](/sites/default/files/Picture%20013.thumb_.jpg)](/sites/default/files/Picture%20013.jpg "Pamphlet Inside.")

[![Windows Vista Meeting advertisement](/sites/default/files/Picture%20006.thumb__0.jpg)](/sites/default/files/Picture%20006_0.jpg "Windows Vista Meeting advertisement")

[![Windows Vista Meeting advertisement, afar.](/sites/default/files/Picture%20014.thumb_.jpg)](/sites/default/files/Picture%20014.jpg "Windows Vista Meeting advertisement, afar.") -->
