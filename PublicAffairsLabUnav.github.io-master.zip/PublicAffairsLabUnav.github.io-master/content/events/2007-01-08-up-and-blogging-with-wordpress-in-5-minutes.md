---
date: 2007-01-08
type: "Meeting"
title: Up and Blogging with Wordpress in 5 Minutes
---
Wordpress is a powerful open-source blog publishing platform.It is highly customizable with a powerful theming system and many available plugins. In this meeting I will show how to install, set up, and manage a Wordpress installation. The talk will also cover Wordpress theming and plugins.
