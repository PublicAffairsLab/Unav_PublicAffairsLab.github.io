---
date: 2008-01-19
type: "Meeting"
title: Student Involvement Fair 2006 Photos
---
A couple of weeks ago we attended the Student Involvement Fair and had a blast.
Here are some photographs of the event courtesy of Peter.

<!-- FIXME -->

<!-- [![](/sites/default/files/DSCF4855.thumbnail.JPG)](/sites/default/files/DSCF4855.JPG "Former ntSig president and current vice-president Anthony Nedolast receives a peace offering of a Ubuntu disc.")

[![](/sites/default/files/DSCF4856.thumbnail.JPG)](/sites/default/files/DSCF4856.JPG "Anthony shows off his Ubuntu CD and his soda-stained pants.")

[![](/sites/default/files/DSCF4857.thumbnail.JPG)](/sites/default/files/DSCF4857.JPG "Jim, Alex, and Tom discussion important issues.")

[![](/sites/default/files/DSCF4858.thumbnail.JPG)](/sites/default/files/DSCF4858.JPG "This is the wonderful banner Peter made for the Involvement Fair. Go Peter!")

[![](/sites/default/files/DSCF4859.thumbnail.JPG)](/sites/default/files/DSCF4859.JPG "You can see our mailing list sign up sheet, The Open Source Definition, an OpenOffice.org pamphlet, and free Ubuntu discs.")

[![](/sites/default/files/DSCF4860.thumbnail.JPG)](/sites/default/files/DSCF4860.JPG "Alex offers Jim a Tootsie-Roll-Pop.")

[![](/sites/default/files/DSCF4861.thumbnail.JPG)](/sites/default/files/DSCF4861.JPG "Jim and Alex look for something across the path.")

[![](/sites/default/files/DSCF4862.thumbnail.JPG)](/sites/default/files/DSCF4862.JPG "Here's a look at the Microsoft-sponsored ntSig booth next to us. You can see their new president, Matt Nedrich.")

[![](/sites/default/files/DSCF4865.thumbnail.JPG)](/sites/default/files/DSCF4865.JPG "Alex, Matt, and Paul discuss OSUOSS/ntSig partnerships.")

[![](/sites/default/files/DSCF4866.thumbnail.JPG)](/sites/default/files/DSCF4866.JPG "Paul shudders inside as Matt's withered claw envelops his hand in a dark embrace.")

[![](/sites/default/files/DSCF4867.thumbnail.JPG)](/sites/default/files/DSCF4867.JPG "ntSig vice-president Andrew Nedolast cries inside as nobody visits his booth.")

[![](/sites/default/files/DSCF4872.thumbnail.JPG)](/sites/default/files/DSCF4872.JPG "It was a wet and cold day; Tom and Peter hold out for sun.")

[![](/sites/default/files/DSCF4873.thumbnail.JPG)](/sites/default/files/DSCF4873.JPG "It is still wet and cold.")

[![](/sites/default/files/DSCF4874.thumbnail.JPG)](/sites/default/files/DSCF4874.JPG "I have no comment for this.")

[![](/sites/default/files/DSCF4876.thumbnail.JPG)](/sites/default/files/DSCF4876.JPG "Ved and Tom help clean up as we get ready to leave the now deserted Special Interest section")

[![](/sites/default/files/DSCF4877.thumbnail.JPG)](/sites/default/files/DSCF4877.JPG "Here is the final picture of the great banner Peter made. It was too soaked to survive. We will miss it.") -->
