---
date: 2011-06-02
title: Web Application Security
---
This Thursday, June 2nd at 7PM in Dreese Labs 264, Jonathan Tubb and Brian Swaney will be presenting on compromising and exploiting web systems and will focus on some of the techniques as well as actual examples. The talk itself will be shorter than a normal meeting so that planning meetings for next year and organizing summer events can take place.

As always the OSU Open Source Club does not condone illegal activities and is not responsible for any misuse of the techniques learned in this meeting. Only experiment on systems you own or are authorized to use for the purpose of testing an exploit.
