---
date: 2017-02-02
title: "Résumé Workshop"
speaker: "The Harris Corporation"
type: "Meeting"
---

Join us this Thursday, February 2nd 2017, at 19:00 as Former OSU grads from Harris Corporation discuss their jobs as software engineers at Harris Corporation. Learn how to properly format your resume to highlight your software skills, and include notable projects you’ve done as a student, to better catch the attention of software recruiters at high-tech companies.
