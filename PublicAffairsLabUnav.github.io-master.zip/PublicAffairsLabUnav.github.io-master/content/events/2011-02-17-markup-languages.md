---
date: 2011-02-17
title: Markup Languages
---
This Thursday, in [Dreese Lab](http://www.osu.edu/map/building.php?building=279) room 264, several of our members will be giving presentations on various markup languages.

Matt Meinwald will be going over XML. Alex Lingo will present HTML. Paul Schwendenman will be educating us on HAML. Silas Baronda will be covering reStructuredText. Daniel Thau will be presenting LaTeX. Finally, Alek Rollyson will be covering Markdown.

If you feel you can cover a markup language that isn't already covered, even briefly, feel free to make a post and we'll see if we can add you. The more the merrier.
