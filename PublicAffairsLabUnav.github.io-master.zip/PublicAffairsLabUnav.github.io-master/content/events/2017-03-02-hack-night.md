---
date: 2017-03-02
title: "Hack Night"
speaker: Various Club Members
type: "Meeting"
---
Join us tonight at 19:00 for a hack night. Bring your projects and questions with you. Have a project that you're working on that you could use help with, bring it with you. Have questions about an open source topic, bring it with you. This meeting is meant to be an opportunity to work on what you want with other enthusiasts as a resource.
