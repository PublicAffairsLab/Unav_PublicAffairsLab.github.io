---
date: 2014-01-16
title: Virtualization
---
Greetings!

This Thursday, January 16th at 7pm in Caldwell Labs 120, Chris Wallace will present "Virtual Servers: An introduction to virtualization in linux".

I'll try to cover some of the common virtual server options in linux such as:

- KVM
- Xen
- OpenVZ
- Virtualbox

and other solutions, as well as practical situations and reasoning for using a virtual server over a physical server.

Hope to see you there!
