---
date: 2013-11-14
title: Developer Tools
---
This Thursday, 2013/14/11 at 7:00pm in Caldwell Labs 120, Maxim Kim will be presenting various developer tools (30min - 1 hour). Text editors, IDEs, standalone utilities help you improve your productivity and reduce the amount of tedious and repetitive work. The presentation will cover popular choices such as Emacs, Eclipse, and IntelliJ, as well as some nice features that they provide. Slides will be [here](http://slid.es/maximkim/developer-tools).

Laptops are encouraged, but not required, and as always, there will be pizza.
