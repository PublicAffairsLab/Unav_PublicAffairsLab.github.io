---
date: 2008-02-28
type: "Meeting"
title: Silverstripe Meeting Tonight
---
We are meeting tonight (Thursday, February 28th) at **6:00 pm** in
**Scott Lab room 103**. Please note that this is not the normal time/location we
meet. We are meeting **one hour before** our normal meeting time, and in
**Scott Lab** instead of Dreese Lab. Our guest speaker, Jim Muir, is a nuclear
and mechanical engineering who had better write solid code, and this
presentation could be volatile, so we can just let Scott Labs bear this one. Jim
Muir is speaking to us about a new open source content management system called
SilverStripe. Pizza will be served and as always everyone is welcome.
