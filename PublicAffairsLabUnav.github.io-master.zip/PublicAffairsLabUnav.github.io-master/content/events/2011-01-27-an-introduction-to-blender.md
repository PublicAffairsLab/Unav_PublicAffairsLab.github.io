---
date: 2011-01-27
type: "Meeting"
title: An Introduction to Blender!
---
This Thursday, Alex Lingo will be presenting on the topic of Blender. Blender is a powerful 3D modeling and rendering program, similar to applications such as Maya or 3DS Max. Alex's presentation will cover the history of blender, basic 3D modeling concepts, how to control Blender with the keyboard and mouse, and will conclude with a live demonstration that will hopefully go as planned, with no mistakes or confusion, guaranteed.
