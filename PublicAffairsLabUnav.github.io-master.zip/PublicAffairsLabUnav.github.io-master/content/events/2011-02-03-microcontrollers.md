---
date: 2011-02-03
title: Microcontrollers
---
This Thursday, February 3 at 7PM in Dreese 264, Jonathan Tubb will be going over the basics of Microcontrollers, uses, and programming. Specific devices will include the TI MSP line of chips as well as Arduino (Atmega). Finished projects will also be brought in as examples. Feel free to bring and show off your own projects.

As always there will be pizza.
