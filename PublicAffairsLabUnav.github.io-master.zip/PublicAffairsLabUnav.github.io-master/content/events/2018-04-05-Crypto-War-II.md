---
date: 2018-04-05
title: "Crypto War II"
speaker: "Matt Curtin"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

This week Matt Curtin from Interhack is coming in to talk on Crypto War II. There are many forces in this world that are concerned and/or interested in the control of cryptography. We're now entering into a second stage of the Crypto Wars, one that could prove much more dangerous to us all.

#### As always, laptops are encouraged and pizza will be provided.
