---
date: 2009-10-07
type: "Meeting"
title: Open Source Club IRC Rules
---

Rules for OSU Open Source Club IRC Channel

Throughout these rules “our”, “us,” and “we” will refer to The Open Source Club at The Ohio State University. Also the following: “your,” “you,” and “yours” will refer to anyone logged into the channel whether they are or are not a member of the club.

*   All information and instructions given within our channel are to be used at your own risk. By following or using any of this information you give up the right to hold us liable for any damages.
*   Spamming is not permitted.
*   You are prohibited from messaging the following through our channel: information that is defamatory, abusive, vulgar, hateful, or violates any law.
*   Please remember this is a channel representing our club. Please attempt to keep all actions, discussions, topics, and messages professional and represent the club in a professional manner as well.
*   All messages sent are the responsibility of the person who sent them. Please remember this channel is logged.
