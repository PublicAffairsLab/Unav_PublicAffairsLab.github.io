---
date: 2012-04-05
title: Portable Unix Shell Scripting
---
Thursday, April 5th 2012 at 7:00PM in [Dreese Lab](http://www.osu.edu/map/building.php?building=279) room 359, Daniel Thau will present on Portable Unix Shell Scripting. This presentation will partially depend on last quarter's Unix Utility talk, but if you missed it you should still be fine.
