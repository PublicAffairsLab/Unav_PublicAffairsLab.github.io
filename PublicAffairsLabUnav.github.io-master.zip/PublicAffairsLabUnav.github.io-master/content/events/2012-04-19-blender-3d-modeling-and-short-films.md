---
date: 2012-04-19
title: Blender 3D Modeling & Short Films
---
Thursday, April 19th at 7:00PM in Dreese 369, Alex Lingo will demonstrating the basic usage of the Blender 3D modeling/rendering program. Blender is an powerful open-source application that is as powerful as professional 3D modeling packages, and has been used to create commercial and open-source 3D films. Several of the Open Movie Project films will be shown during the presentation!

Please come prepared with a 3-button mouse and a keyboard with a number pad if you wish to follow along.
