---
date: 2015-08-30
title: Linux Installfest
speaker: OSC
type: Meeting
---

Hi everyone,

This Thursday, 2015/08/30 at 7:00PM in Caldwell Labs 120, the Open Source Club will hold our annual Linux Installfest. We'll be helping you to install GNU/Linux on your machines, and will be available to answer any questions you may have. We will be providing a handful of bootable USBs and discs, preloaded with various linux distributions.

Laptops and chargers are encouraged but not required, and as always, there will be pizza.
