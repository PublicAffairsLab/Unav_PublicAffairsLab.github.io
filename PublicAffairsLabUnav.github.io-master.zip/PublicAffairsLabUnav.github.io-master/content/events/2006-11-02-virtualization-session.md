---
date: 2006-11-02
type: "Meeting"
title: Virtualization Session
---
A big thanks to everyone who made it to today's meeting on Virtualization! We
had a great turnout, great discussion and some pretty hillarious demos!
<!-- Slides from the presentation are available here: -->

<!-- FIXME -->
<!-- [ [OpenOffice](/sites/default/files/virtualization.odp) | [pdf](/sites/default/files/virtualization.pdf) ]  -->

Also, here are some URLs that I promised to post:

- [Xen Project](http://www.cl.cam.ac.uk/research/srg/netos/xen/) at [University of Cambridge](http://www.cam.ac.uk/)
- [XenSource Home Page](http://www.xensource.com/) (very cool flash demo here)
- [XenSource LiveCD](http://www.xensource.com/xen/downloads/) (used for today's demo)
- [Xen Documentation](http://www.cl.cam.ac.uk/research/srg/netos/xen/documentation.html)
- [Xen and the Art of Virtualization](http://www.cl.cam.ac.uk/research/srg/netos/papers/2003-xensosp.pdf)
