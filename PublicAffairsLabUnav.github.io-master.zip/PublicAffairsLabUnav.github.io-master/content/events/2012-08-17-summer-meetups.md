---
date: 2012-08-17
title: Summer Meetups
---
This week's meetup will be at Mad Mex on Friday 2012/08/17 at 7:00pm. Mad Mex is located at 1542 N. High St.

-- Michael
