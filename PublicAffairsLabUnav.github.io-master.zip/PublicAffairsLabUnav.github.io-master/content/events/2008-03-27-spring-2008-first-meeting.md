---
date: 2008-03-27
type: "Meeting"
title: Spring 2008 - First Meeting
---
We had our first meeting for the quarter in Dreese Labs room 266 at 7:00 pm.
Meetings end whenever they end, with no specific time. No absolute topic was
decided on, so we discussed a few random things, such as South Park creators
Trey Parker and Matt Stone streaming [South Park online](http://blog.wired.com/underwire/2008/03/south-park-to-o.html)
for free (where we legally watched a recent episode from Season 12, which does
play in Linux without DRM hacks), Adobe creating a web-based free express
(and watered down) version of [Photoshop](https://www.photoshop.com/express/),
we also spent a few minutes sharing our web-development views. The meeting was
open to students and non-students alike, and pizza was served as always.
Altogether we had a great turnout and I look forward to a similar turnout at
our next meeting.
