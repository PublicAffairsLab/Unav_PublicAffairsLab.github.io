---
date: 2016-09-22
title: Harris Corp on embedded software
speaker: Tim Armstrong
type: Meeting
---
Join us this Thursday, September 22, at 19:00EDT as Tim Armstrong from Harris Corporation talks about embedded software. Tim is an Ohio State alumni and would love to answer your questions about anything from embedded software to life after college. 
