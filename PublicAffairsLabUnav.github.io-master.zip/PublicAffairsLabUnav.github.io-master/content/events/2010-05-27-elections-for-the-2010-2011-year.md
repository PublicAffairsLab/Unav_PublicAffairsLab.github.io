---
date: 2010-05-27
type: "Meeting"
title: Elections for the 2010/2011 Year
---
On **Thursday, May 27th at 7PM (before our regularly scheduled meeting) in Dreese Labs 305,** we will be holding officer elections for the coming 2010/2011 year. If you are interested in running for a position, send an email to elections@opensource.osu.edu with your full name, year, major and a short description of yourself and/or running platform. The elections will last a half hour and the regular meeting will begin at 7:30 PM. The following members are currently running for officer positions:

#### President:

-   Matt Meinwald **Elected!**

#### Vice President:

- Michael Yanovich
- Daniel Thau **Elected!**
- Brian Swaney

#### Treasurer:

- Paul Schwendenman **Elected!**
