---
date: 2015-04-16
title: Lightning Talks
speaker: Various Club Members
type: Meeting
---
Hi everyone,

This Thursday, 2015-04-16 @ 7:00pm in Caldwell Labs 120, The Open Source Club will present Lightning Talks.

This will be an informal space: Anyone who wants to speak will be granted a minimum of 5 minutes to share their topic of choice. Slides aren't required at all- come share something you're working on or something you love.

In the past, these are great opportunities to get better at speaking in order to do full meeting.

Laptops are encouraged but not required, and as always, there will be pizza.
