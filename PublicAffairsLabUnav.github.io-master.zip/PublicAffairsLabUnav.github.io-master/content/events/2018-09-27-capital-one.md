---
date: 2018-09-27
title: "Trends in Open Source"
speaker: "Capital One"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

This week we will be having Capital One in to talk about trends in open source software!

It is also worth mentioning Capital One is offering an internship program and a career development program for recent graduates. The links are below:

  *   [Technology Internship Program (TIP)](https://campus.capitalone.com/job/mclean/technology-development-program-intern-18-19/1786/8903613)
  *   [Technology Development Program (TDP)](https://campus.capitalone.com/job/mclean/technology-development-program-associate-18-19/1786/8903611)

#### As always, laptops are encouraged and pizza will be provided.
