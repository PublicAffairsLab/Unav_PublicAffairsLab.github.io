---
date: 2009-05-29
type: "Meeting"
title: Updating the Constitution
---
This Thursday, June 4th, we are reviewing and revising the club constitution, as well as working out the logistics of what we will be doing in the next year. Please come ready to offer feedback. Also, as of today the website is open for commenting. Please post any ideas about changes you have on the constitution page. Registration required.
