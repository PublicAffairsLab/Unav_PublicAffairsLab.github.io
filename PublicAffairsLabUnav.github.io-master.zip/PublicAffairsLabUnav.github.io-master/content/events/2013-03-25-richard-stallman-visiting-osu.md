---
date: 2013-03-25
title: Richard Stallman visiting OSU
---
This Monday, Richard Stallman is visiting OSU as a guest lecturer in the computer science department. His presentation will be at 4 pm in the [Journalism Building](http://www.osu.edu/map/building.php?building=046), room 300, and the lecture is open to the public.

Attached are some pictures taken. All photos are licensed [CC-BY-ND](http://creativecommons.org/licenses/by-nd/3.0/us/).

Ben Keith took the photo of Saint iGNUcius, while David Ritz took the group picture, and the pictures of the poster.

One of our members also uploaded a [recording of the talk](/~karason/richard_stallman_talk.flac) (also [ogg](http://f.benlk.com/rms-2013-04-15-osu-cc-by-nd.ogg)).
