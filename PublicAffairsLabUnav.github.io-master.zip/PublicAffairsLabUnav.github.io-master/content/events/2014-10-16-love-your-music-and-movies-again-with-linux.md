---
date: 2014-10-16
title: Love your Music and Movies again with Linux
speaker: Chris Wallace
type: Meeting
---
Thursday, 2014-10-16 at 7:00pm in Caldwell Labs 120, Chris Wallace will present Love your Music and Movies again with Linux. Description follows:

The year is 2014: home theater PCs are all but extinct... or are they? This talk will help you reinvigorate your media collection with a home media center, complete with intranet access and a killer frontend. We'll cover some of the fun of Plex, XBMC, and MythTV. As a bonus, we'll even show you what you can do with using a Raspberry Pi.

After this talk, you should be able to breathe some life into all that music and video, all using free software!

Laptops are encouraged but not required, and as always, there will be pizza.
