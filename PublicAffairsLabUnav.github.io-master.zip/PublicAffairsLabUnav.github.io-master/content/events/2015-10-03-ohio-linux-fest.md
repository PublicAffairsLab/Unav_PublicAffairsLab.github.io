---
date: 2015-10-03
title: Ohio LinuxFest 2015
speaker: OSC
type: Convention
---

The Open Source Club is a proud sponsor of [Ohio LinuxFest 2015](https://ohiolinux.org/). So come out and join us on October 2nd & 3rd at the Greater Columbus Convention Center.
