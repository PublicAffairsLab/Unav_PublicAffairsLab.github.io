---
date: 2013-08-22
title: What is Open Source
---
This Thursday 2013/08/22 at 7pm in Dreese Labs 266, Chris Wallace will present our very first meeting of the 2013-2014 academic year "What is Open Source". As in the past, this first meeting will serve as an introduction to what the term open source means and is about, as well as what we do in this club. We will also discuss current privacy issues (PRISM and friends), and free/open source alternatives to popular products.

Laptops are always encouraged, though not required, and as always, there will be pizza.
