---
date: 2016-09-08
title: Intro to the Command line
speaker: "Brandon 'Bam' Moore (malide)"
type: Meeting
---
If you're new to the command line, stop on by and we can get you comfortable with the terminal. Be it moving around, updating software, or anything else in your daily computing needs. 

If you can navigate your way around the terminal just fine, don't skip this meeting yet, we'll be discussing different shells and tips and tricks. Want to get a nice customized setup nice and quick, try FISH or OH-MY-ZSH. Plan on jumping between systems with little control, make sure you know Bash or Csh.

We strongly encourage that you come with a Unix-based system such as Linux or BSD(VMs are acceptable). As always there will be pizza.
