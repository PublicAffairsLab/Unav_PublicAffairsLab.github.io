---
date: 2010-04-15
type: "Meeting"
title: Nifty Tips and Tricks
---
This **Thursday, April 15th at 7PM in Dreese Labs 305,** we will be hosting a discussion session revolving around tips, tricks, and time savers that people have discovered. Do you think you have an awesome .bashrc, .vimrc, key binding, or a little known useful program and want to show it off? This would be the perfect opportunity to share with the rest of the club. There are lots of nifty things that are not widely known and we think this would be a good opportunity to share your knowledge of time savers with others! We will not be using the typical presentation format in lieu of a more informal discussion atmosphere, so feel free to come on out and share your tips as well as learn some new ones at the same time. Hope to see you there!
