---
date: 2014-02-20
title: OSC Goes to COLUG! (OpenStack)
---
Greetings Everyone,

This Thursday, 2014/02/20 at 7pm until 9pm at TechColumbus, the Central Ohio Linux Users Group and Red Hat will be presenting OpenStack. Heres info below:

Perry Myers from Red Hat will present OpenStack. He'll demo
installation, and provide an overview of the various OpenStack
components: Keystone, Cinder, Glance, Neutron, Nova, Swift and more!

As always, feel free to bring with you any ailing or problematic
systems for expert diagnosis (or destruction).
In order to get out there, the Open Source Club will have carpooling from Caldwell Labs to Tech Columbus, meaning:

    At 6:30-6:45 we will leave from the back entrance of Caldwell (near CL120 where we normally meet)
    At 9:00 we will leave TechColumbus and return everyone to Caldwell Labs

If you would like to help carpool, bring your car to the back entrance of Caldwell at 6:30.
The Address is:
  TechColumbus
  1275 Kinnear Rd,
  Columbus, OH 43212

Additionally: TechColumbus is about a 5 minute walk from the Carmack 4 bus stop on west campus. If you for some reason cannot get a ride with us, feel free to use the CABS bus system instead.

There will be pizza.
