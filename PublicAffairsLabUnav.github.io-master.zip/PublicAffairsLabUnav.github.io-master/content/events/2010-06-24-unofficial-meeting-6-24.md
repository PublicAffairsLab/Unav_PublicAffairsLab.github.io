---
date: 2010-06-24
type: "Meeting"
title: Unofficial Meeting 6/24
---
On Thursday, June 24 at 7:00 PM, in **Dreese 305**, there is an unofficial meeting, hosted by Alex Lingo. The main topic is planning these kinds of meetings for the rest of the summer, but there should be plenty of interesting discussion.
