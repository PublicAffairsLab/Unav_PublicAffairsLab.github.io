---
date: 2011-09-22
title: First meeting
---
Thursday, September 22nd at 7:00PM in Dreese Labs room 266, the Ohio State University Open Source Club will have its first meeting of the 2011-2012 academic year.  Daniel Thau will be giving an introduction to the concept of Free/Open Source Software to help explain to any [potential] new members what the club is about.  After that we'll have a PGP signing party (we'll likely have a talk on what PGP is some time next quarter).

We should have pizza available as well.  

Everyone is welcome, irrelevant of knowledge or experience with Free/Open Source Software.  Hope to see you there!
