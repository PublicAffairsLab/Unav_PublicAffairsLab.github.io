---
date: 2008-09-25
type: "Meeting"
title: Welcome Week Introductions
---
We have scheduled a meeting for Thursday, September 25th at 7:00 pm in
[Dreese Labs](http://www.osu.edu/map/building.php?building=279) room 266. There
is no official meeting topic as we will spend the time doing introductions
(trying to be sociable or something to that extent). Meetings are open to
everyone as always, so please stop by.
