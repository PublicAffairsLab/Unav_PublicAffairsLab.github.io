---
date: 2015-10-12
title: BDAA Career Fair
speaker: OSC
type: Volunteer
---

Come volunteer at the BBDA Career Fair.

- Date: Wednesday, October 21st, 2015
- Where: The Union Cartoon Room
- Time: 12-3pm

Various volunteers needed from 9:30 am-3:30pm
