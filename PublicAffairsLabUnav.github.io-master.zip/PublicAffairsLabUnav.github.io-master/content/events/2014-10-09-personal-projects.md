---
date: 2014-10-09
title: Personal Projects Lightning Talks
speaker: Various Club Members
type: Meeting
---
Hi everyone!

This Thursday, 2014-10-09 in Caldwell Labs 120, The Open Source Club at The Ohio State University will present Personal Projects.

This series of lightning talks will give an opportunity for members of The Open Source Club to show off the stuff that they've been making, whether at hackathons or in their spare time. Even class projects can be interesting.

The talk format is open to everyone, but if you want to 100% reserve space email meetings@opensource.osu.edu.

Laptops are encouraged but not required, and as always, there will be pizza.
