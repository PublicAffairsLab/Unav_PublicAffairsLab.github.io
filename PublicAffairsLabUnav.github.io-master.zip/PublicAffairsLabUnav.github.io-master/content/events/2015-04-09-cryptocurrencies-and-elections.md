---
date: 2015-04-09
title: Cryptocurrencies and Elections
speakers: Alex Krieger (kriegersaurusrex)
type: Meeting
---
Thursday, 2015-04-09, Alex Krieger will present Cryptocurrencies. This will provide more of the technical details of how these schemes (such as Bitcoin, Litecoin, and Dogecoin) work.

In addition, there will be elections this week. As always, membership is required to vote. As defined by our constitution, this is having attended at least one meeting prior.

Laptops are encouraged but not required, and as always, there will be pizza.
