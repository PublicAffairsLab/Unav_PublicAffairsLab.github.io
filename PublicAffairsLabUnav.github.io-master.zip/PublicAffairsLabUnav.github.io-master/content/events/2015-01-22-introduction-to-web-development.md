---
date: 2015-01-22
title: Introduction to Web Development
speaker: Jonathan Arnett (J3RN)
type: Meeting
---
Thursday, 2015-01-22, Jon Arnett (President of the Collegiate Web Developer Group here on campus) and Eli Gladman will present "Intro to Web Development". A description from Jon follows:

Eli and I will be giving an introduction to web development using Ruby on Rails. Ruby is an open source programming language that first surfaced in the 90's, and gained popularity through it's expressive syntax and powerful features, such as metaprogramming. The Rails web development framework is written in Ruby, and is known for allowing developers to iterate extremely quickly. To illustrate this point, we intend to build a functional (though perhaps unstyled) blog in a fraction of the time it would take to write in another language or framework.

Laptops are encouraged but not required, and as always, there will be pizza.
