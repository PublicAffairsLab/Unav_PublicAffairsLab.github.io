---
date: 2016-11-10
title: The ELK Stack
speaker: David Soller
type: Meeting
---

This Thursday, November 10th 2016, David Soller will be presenting the ELK
stack.

The talk will center around the ELK stack and its ability “to take data from any
source and search, analyze, and visualize it in real time.”(Elastic.co) Each of
the ELK stacks open source projects Elasticsearch, Logstash and Kibana will be
covered.
