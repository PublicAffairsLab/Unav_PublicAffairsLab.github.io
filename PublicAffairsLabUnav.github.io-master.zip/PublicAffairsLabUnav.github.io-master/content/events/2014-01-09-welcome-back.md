---
date: 2014-01-09
title: Welcome Back
---
Hello everyone!

I hope everyones break (as well as additional days off) have been swell. To celebrate, this Thursday, January 9 at 7pm in Caldwell Labs 120 we will be having an open-ended meeting with open discussion. To make things cooler, we will have nice pizza (adriadicos) and a raspberry pi and arduino to play around on.

This meeting will also be where we plan future meetings for the semester, so come with any ideas you may have!

I look forward to seeing you all back.
