---
date: 2008-11-06
type: "Meeting"
title: Interface Design
---
This Thursday we will be having a guest speaker come in and teach us about
interface design. The speaker will be Matthew Stanford, who is currently working
on his masters degree over in the design department. You may think that design
isn't important, but I have learned from experience that your really awesome
code will go unnoticed if you don't have a nice interface to go with it. I urge
you to come if you can because this is a very important presentation that will
help everyone make their work more presentable. The meeting will be at 7p in
266 Dreese.
