---
date: 2014-02-27
title: Crypto Currencies
---
Greetings everyone, sorry for the late email this week.

This Thursday, 2014/02/27 at 7pm in Caldwell Labs 120, Chris Wallace of the Open Source Club will give a talk on crypto currencies.

The talk will cover different parts of how these currencies work, and will also touch on some of the controversies surrounding these currencies. Popular CCs include:

- Bitcoin
- Litecoin
- Namecoin
- Dogecoin

Laptops are encouraged but not required, and as always, there will be pizza.
