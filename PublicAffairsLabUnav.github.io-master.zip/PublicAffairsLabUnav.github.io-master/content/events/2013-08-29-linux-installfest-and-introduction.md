---
date: 2013-08-29
title: Linux InstallFest and Introduction
---
Thursday 2013/08/29 at 7pm in Dreese Lab 266, Chris Wallace and the Open Source Club will present "Linux InstallFest and Introduction". This meeting will consist of two different hour-long blocks. In the first section, we will provide installation media for different distributions of the GNU/Linux operating system, with seasoned members present to help get those interested installed. In the second hour, we will provide an introduction to the GNU/Linux command line environment.

Overall, we would like you to not only have GNU/Linux installed, but also have a pretty good idea of the things you can do with it.

Laptops are always encouraged, though not required, and as always, there will be pizza.
