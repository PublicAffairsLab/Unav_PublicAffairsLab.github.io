---
date: 2014-10-23
title: Open Source at Facebook
speaker: Patrick Shuff from Facebook
type: Meeting
---
Thursday, 2014-10-23 at 7:00pm in Caldwell Labs 120, Patrick Shuff (an engineer at Facebook) will present "Open Source at Facebook". Description follows:

Facebook serves requests for over 1.3 billion people every month.  I will give a brief overview of our Traffic/CDN (e.g. images and videos) infrastructure and how open source software is core to being able to deliver all of those bits to the world every day!

Laptops are encouraged but not required, and as always, there will be pizza.
