---
date: 2016-01-21
title: Meeting Planning + Lightning Talks
speaker: Various Club Members
type: Meeting
---
Tonight's meeting will be drafting future talks for the semester + some
lightning talks; and I'm going to give a condensed version of a powerpoint at a
conference that I saw on Monday dealing with the economics of zero-day
vulnerabilities. Future meeting dates will posted on the website as they're
determined.
