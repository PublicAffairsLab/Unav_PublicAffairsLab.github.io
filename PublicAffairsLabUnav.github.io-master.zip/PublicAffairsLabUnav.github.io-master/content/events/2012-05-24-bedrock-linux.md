---
date: 2012-05-24
title: Bedrock Linux
---
Thursday, May 24th at 7:00PM in Dreese 369, Daniel Thau will be presenting Bedrock Linux.  Bedrock Linux is a Linux distribution created by Daniel with the aim of making most of the (often seemingly mutually-exclusive) benefits of various other Linux distributions available simultaneously and transparently.  For example, if one would like a rock-solid stable base (for example, from Debian or a RHEL clone) yet still have easy access to cutting-edge packages (from, say, Arch Linux), Bedrock will provide a means to achieve this.
