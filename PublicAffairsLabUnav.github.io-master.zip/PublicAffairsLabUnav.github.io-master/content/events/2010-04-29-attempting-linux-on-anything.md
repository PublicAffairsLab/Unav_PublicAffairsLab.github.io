---
date: 2010-04-29
type: "Meeting"
title: (Attempting) Linux on Anything
---
This **Thursday, April 29th at 7PM in Dreese Labs 317,** we will be spending the meeting time attempting to install Linux on anything. We have members with PS3's, iPods, XBOX's, Wii's, phones and whatever else you can think of and we are going to attempt to install an operating system of our choice on them. These members are volunteering their hardware for the meeting and recognize that performing these actions may violate warranties and are not responsible for attempts made meeting goers' own electronics. We are only showing these demonstrations as proof of concept that it is possible to put your own software on hardware that, when it boils down to it, is essentially just a computer built for a specific purpose. So, if you are interested in talking about trying to put Linux on anything and everything, come on out and join in on the fun. Hope to see you there!
