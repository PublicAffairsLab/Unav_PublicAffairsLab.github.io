---
date: 2009-10-09
type: "Meeting"
title: Scott Merrill from Columbus FreeGeek
---
On Thursday October 15th, 2009, Scott Merrill from Columbus FreeGeek presented on how to get involved in the tech scene here in Columbus. FreeGeek Columbus provides computers and training for limited-resource populations in Central Ohio through redistribution of used equipment and the use of Free Software. FreeGeek Columbus is committed to Free Software, responsible electronics recycling, and community engagement. In his presentation, Scott gave us a brief overview of who FreeGeek is and what they do, touch upon the hazards of electronic waste, describe how FreeGeek rewards volunteers, and share how they're advocating Ubuntu Linux to people. After his presentation Scott answered everyone's questions! As always, there will be pizza! **Update:**At the end of this meeting, we voted on finalizing some constitutional amendments from [last year](/node/88). Find changes attached.
