---
date: 2015-02-12
title: MediaWiki
speaker: Kevin Payravi
type: Meeting
---
This Thursday, 2015-02-12 at 7:00pm in Caldwell Labs 120, Kevin Payravi will present "MediaWiki". Description follows:

"I'll be introducing MediaWiki, Wikimedia's open-source software for powering thousands of wikis (including Wikipedia). We'll take a look at its development, how anyone can contribute, and do a quick set up on a DigitalOcean droplet. "

Laptops are encouraged but not required, and as always, there will be pizza.
