---
date: 2013-09-05
title: Introduction to Command Line
---
This Thursday, September 5th at 7pm in Caldwell Labs 120, Brad Hollander will present "Introduction to the Command Line". This presentation/lecture is geared toward beginner users of the GNU/Linux OS, with an end goal of getting participants comfortable in a shell environment. Questions will be welcome at any time throughout the presentation as well.

Laptops are encouraged, but not required, and as always, there will be pizza.
