---
date: 2012-04-12
title: Sage Mathematics
---
On Thursday the 12th, in [Dreese Lab](http://www.osu.edu/map/building.php?building=279) room 369, Daniel Thau will present the Sage mathematics program. Sage is intended to be an open source alternative to software such as Magma, Maple, Mathematica and Matlab. Based around Python, it is quite pleasant to script and surprising capable.
