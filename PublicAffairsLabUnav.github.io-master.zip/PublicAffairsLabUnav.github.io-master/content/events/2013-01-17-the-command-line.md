---
date: 2013-01-17
title: The Command Line
---
Hello everyone!

This Thursday, January 17th, at 7pm in Dreese Lab 369, Brad Hollander will be presenting The Command Line. This will serve as an introduction to basic and advanced features of the command line, as well as tools, utilities, and applications that are available. Additionally, there will be a short introduction to vim near the end from Daniel Thau.

The hope is that by the end you should be more successful and know practical tools relating to the command line in Linux/Unix.

As always, there will be pizza.
