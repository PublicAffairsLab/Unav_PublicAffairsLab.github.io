---
date: 2012-11-22
title: No Meeting this Week
---
Due to the Thanksgiving holiday on Thursday, we will not have a meeting this week. The next meeting is November 29<sup>th</sup>. More details on that upcoming meeting will be posted soon.
