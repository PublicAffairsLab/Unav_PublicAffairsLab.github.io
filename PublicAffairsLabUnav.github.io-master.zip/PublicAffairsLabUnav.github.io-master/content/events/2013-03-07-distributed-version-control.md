---
date: 2013-03-07
title: Distributed Version Control
---
This Thursday, 2013/03/07 at 7pm in Dreese Labs 369, the Ohio State Open Source Club will be presenting "Distributed Version Control v1" This meeting will be presented by Paul Schwendenman.

The meeting will lightly touch on some made-up history of version control and then information and examples related to bazaar, git and mercurial. At the end of this meeting you should be able to comfortably work with a distributed version control system.

As always, there may be some pizza.
