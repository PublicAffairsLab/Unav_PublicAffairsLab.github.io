---
date: 2013-04-11
title: Security and Elections
---
This Thursday, 2013/04/11 at 7:00pm in Dreese Labs 369, the Ohio State Open Source Club will be presenting Security. This will be a talk consisting of multiple members going up and speaking about different topics in the open source world of security.

Additionally, elections will be taking place at this meeting. If anyone would still like to run, please email elections@opensource.osu.edu with a quick blurb about what you're running for.

Finally, the CSE Department is hosting Richard Matthew Stallman (rms) for "Free Software and Your Freedom" on Monday, 2013/04/15 at 4pm in **Journalism Building 300** (note the room change). All are welcome to attend. For more information, visit http://www.cse.ohio-state.edu/speaker/speaker273.shtml.
