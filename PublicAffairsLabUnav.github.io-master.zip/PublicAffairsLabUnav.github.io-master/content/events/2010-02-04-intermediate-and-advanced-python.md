---
date: 2010-02-04
type: "Meeting"
title: Intermediate and Advanced Python
---
Thursday February 4th, at 7PM in Dreese Labs 266, Michael Yanovich and Morgan Goose will be demonstrating some intermediate and advanced uses of Python. They have several tips and tricks to demonstrate, so come out and learn more about the Python language! Morgan's [slides](http://morgangoose.com/p/tool_oriented_python/) are available and notes are attached.
