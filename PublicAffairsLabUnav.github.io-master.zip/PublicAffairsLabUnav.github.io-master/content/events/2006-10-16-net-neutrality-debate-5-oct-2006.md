---
date: 2006-10-16
type: "Meeting"
title: 'Net Neutrality Debate : 5 Oct 2006'
---
A dual perspective approach to the Net Neutrality debate. Think of it as driving on the highway and you can go 60mph for a regular rate, or 80mph at a more expensive rate. Everyone is in favor of being able to pay more to go faster, but net neutrality adds that the guy at 60 should be able to go everywhere that the guy at 80 can go without additional charges.

That might or might not be accurate, but it has scary things in it like the Patriot Act, but nobody has actually read either one.

Conclusion: unresolved
