---
date: 2014-02-06
title: Filesystems
---
This Thursday, February 6th at 7:00pm in Caldwell Labs 120, Paul Schellin will present "Filesystems"

This topic will cover:
- A history on filesystems
- Examples of current and past FSs
- Virtual filesystems
- A custom-built filesystem
- anything else!

Laptops are encouraged though not required, and as always, there will be pizza.
