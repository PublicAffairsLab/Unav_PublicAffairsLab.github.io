---
date: 2006-09-21
type: "Meeting"
title: Avast, me hearties!
stories:
    - title: "Talk like a pirate day"
      link: "http://talklikeapirate.com/"
      notes: |
        Ye be warned! [Talk like a pirate day](http://talklikeapirate.com/) be the 19th of September.
---
