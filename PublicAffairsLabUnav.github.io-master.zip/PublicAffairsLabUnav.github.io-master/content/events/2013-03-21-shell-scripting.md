---
date: 2013-03-21
title: Shell Scripting
---
Thursday, March 21nd, 2013 in Dreese Labs 369, Daniel Thau will present an introduction to POSIX Bourne shell scripting.  A general familiarity with a UNIX command line environment and UNIX utilities (grep, sed, awk, etc) will be useful but not required. If you've ever expressed interest in making your life easier at the command line, this could be the talk for you.

Additionally, elections will be taking place at our second to last meeting of the semester (2013/04/11). If anyone would like to run for one of our three positions (President, Vice President, or Treasurer), please email elections@opensource.osu.edu with a quick blurb about what you're running for.

As always, there will be pizza.
