---
date: 2017-03-09
title: "Ansible And Elections"
speaker: "Andrew Cz (smacz)"
type: "Meeting"
---

Join us this Thursday, March 9th 2017, at 19:00 in Dreese 264 for a talk by Smacz on the popular automation software, Ansible. Used in industry for tasks such as configuration management, Ansible is often used to keep servers synchronized with standardized settings. Ansible was developed by RedHat to simplify automation and provide an easy to read syntax.

Elections for 2017-2018 officers are also Thursday. If you're an undergraduate student graduating May of 2018 or later, you are a viable candidate. Positions include, but are not limited to, president, vice president, and treasurer. Make sure to make it to the meeting on time if you want to run for a position, as elections will start at 19:00.
