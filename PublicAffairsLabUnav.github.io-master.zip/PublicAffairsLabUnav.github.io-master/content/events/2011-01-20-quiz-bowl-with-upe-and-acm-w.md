---
date: 2011-01-20
type: "Party"
title: Quiz Bowl with UPE and ACM-W
---
This Thursday, January 20, in ***Dreese Labs room 480*** at 7PM, we will be participating in a quiz bowl event with [UPE](http://www.cse.ohio-state.edu/upe/) and [ACM-W](http://acmw.org.ohio-state.edu/). This event will consist of a qualifier round where two teams of four will be selected based on individual knowledge of computer science trivia. These teams will face each other, then the winning team will face a faculty team. There will be pizza, pop, and prizes.

Attached is a flyer for this event.
