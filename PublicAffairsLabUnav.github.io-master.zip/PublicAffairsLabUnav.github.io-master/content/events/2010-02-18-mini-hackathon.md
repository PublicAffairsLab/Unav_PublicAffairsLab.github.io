---
date: 2010-02-18
type: "Party"
title: Mini Hackathon!
---
Due to mitigating circumstances we will not be having our [maximizing battery talk](/announcements/2010/02/16/maximizing-battery-life-in-linux/) this week. In lieu of this we will be holding a hackathon in its stead. This ***Thursday, February 18th at 7PM in Dreese Labs 266***, we will be hacking on all sorts of code. We have several projects going at the moment that range from python to C and hackers of all skill levels are invited. Whether you know nothing about programming or are a kernel wizard come join us and play around with some code. There will be no formal structure to this meeting, just bring your laptop and/or your brain and you will be able to hack along. You may want to familiarize yourself slightly with the projects in [gitweb](/git) and find one or more you may want to work on. Of course you could also bring your own. As always, there will be pizza.
