---
date: 2009-11-04
type: "Meeting"
title: Linux Install Fest
---
For those who don't know, Microsoft had (is having) a Windows 7 install fest. On November 5, 2009 after our regularly scheduled meeting The Open Source Club will likewise be hosting an Install-Fest of *free*, open source software. This is rather last minute, but you won't be disappointed if you show up! We are giving away free and open-source applications and operating systems. Plus if you are really eager to getting the software or even an operating system on your laptop we will be gladly installing them for you.

The location will be in Dreese 266 after our meeting that regularly starts at 7:00pm.
