---
date: 2013-09-26
title: Desktop Applications
---
This Thursday, 2013/09/26 at 7pm, in Caldwell Labs 120, we will have multiple speakers presenting their favorite desktop applications. Explore the open source apps that are great for office productivity, music, movies, image and video editing, teleconferencing. If you want to talk about your favorite app, let us know at meetings@opensource.osu.edu

Additionally, we will be doing initial signups for the Hackathon that's been mentioned at this meeting. Also, we will be doing account requests for the Open Source Club computers too.

Laptops are encouraged but not required, and as always, there will be pizza.
