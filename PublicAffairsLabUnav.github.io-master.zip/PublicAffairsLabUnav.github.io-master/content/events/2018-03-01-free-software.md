---
date: 2018-03-01
title: "Free Software"
speaker: "Chris `brainblasted` Davis"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

This week, Chris will be giving a talk on free software, and how using it can help you protect your privacy.

#### As always, laptops are encouraged and pizza will be provided.
