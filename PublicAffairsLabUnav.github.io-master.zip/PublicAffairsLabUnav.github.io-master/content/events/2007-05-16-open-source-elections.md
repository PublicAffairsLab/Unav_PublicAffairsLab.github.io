---
date: 2007-05-16
type: "Meeting"
title: Open Source Elections
---
The Open Source Club at The Ohio State University (OSSOSU) will be holding
officer elections to represent us for the next (07-08) school year. The
eligibility requirements for being an officer are that you are a student at
Ohio State, and that you are a member of the club (have attended at least one
meeting). Graduate and undergraduates are both equals in this matter.

Open Positions: Benevolent Dictator, Number Two, and Treasurer

Office Holders for school year 2006-2007 are:

 - Benevolent Dictator: Alex Lingo
 - Number Two: Tom Hess
 - Treasurer: Peter Dietz

Benevolent Dictator will be known as President to the university must attend
training meetings, as well as the treasurer. Number Two just has to look pretty.

P.S. I rearranged the office.

<br>

EDIT: October 2007

Elections have happened and the 2007-2008 officers are:

 - Benevolent Dictator: Peter Dietz
 - Number Two: Alex Lingo
 - Treasurer: Razvan Lupusoru
