---
date: 2013-04-18
title: End of the Year
---
This Thursday, 2013/04/18 at 7:00pm in Dreese Labs 369, the Ohio State Open Source Club will be having an End of the Year meeting. We will be having some nice(er) pizza and drinks, and have an open discussion. This can be everything from Free software and RMS to a personal project you have been working on and want to share, it's all up to you.

As always, all meetings are open to the public.
