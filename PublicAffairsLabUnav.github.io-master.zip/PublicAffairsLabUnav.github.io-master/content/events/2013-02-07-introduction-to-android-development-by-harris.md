---
date: 2013-02-07
title: Introduction to Android Development by Harris
---
Hello everyone!

This Thursday, 2013/02/07 at 7pm in Dreese Labs 369, Hussain Frosh of Harris will be presenting an introduction to development for Android. This talk will assume that the user will be starting from scratch, with no prior knowledge of developing for Android. Java experience is encouraged, but not required for the scope of this talk.

We recommend bringing a laptop, as the goal for this presentation is to have all participants set up and comfortable with the development environment for Android.

As always, there will be pizza.
