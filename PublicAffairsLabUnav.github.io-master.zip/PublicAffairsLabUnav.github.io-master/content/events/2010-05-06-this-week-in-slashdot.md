---
date: 2010-05-06
type: "Meeting"
title: This Week In Slashdot
---
This **Thursday, May 6th at 7PM in *Caldwell 133* (note the change),** Alex Lingo will be presenting an old club favorite known as "This Week in Slashdot". Slashdot (commonly abbreviated as /.) is a website located at http://slashdot.org that deals in news for the nerdy. Readers submit articles which are then accepted or rejected by editors and then published on the site. From there, the readers have huge discussions about every aspect of the article which can be very funny/interesting/insightful/etc and oft prove to be a very good read. Historically, the site has a history of having a pro open source bias, which is why we like it. Alex would like to take this format and apply it to a club meeting so that we can have similar discussions amongst our members in real time. No prior knowledge of /., or goings on in the world, is necessary to participate. Read slashdot prior to the meeting if you wish and bring your thoughts, opinions, ideas, rants, raves and what have you. I hope to see you all there, we love a good discussion!
