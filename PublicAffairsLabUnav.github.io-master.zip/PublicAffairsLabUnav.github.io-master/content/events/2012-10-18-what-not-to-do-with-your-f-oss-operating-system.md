---
date: 2012-10-18
title: What NOT to do with your F/OSS Operating System
---
Hey everyone,

This Thursday, 2012/10/18 at 7pm in Dreese Labs 266, The Ohio State Open Source Club will be presenting "What NOT to do with your F/OSS Operating System."

This talk will be done a little more casual, with members sharing disaster stories of what they have done to their operating systems.

I encourage everyone to participate, I just ask that you email me back with these three fields so that I may make you a slide:

- Operating System
- What broke
- Solution if there was one

also please have around 5 minutes of material to your story, if possible. As always, there will be pizza.
