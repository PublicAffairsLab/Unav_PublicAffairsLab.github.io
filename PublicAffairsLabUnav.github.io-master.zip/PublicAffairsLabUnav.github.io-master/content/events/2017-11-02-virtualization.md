---
date: 2017-11-02
title: "Virtualization"
speaker: "Andrew `smacz` Cziryak"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

The week one of our own will be giving a talk on virtualization! This will be a good chance to get some knowledge if you are interested, or to find out if you are interested. As always, free pizza will be provided!
