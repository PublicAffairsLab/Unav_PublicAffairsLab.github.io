---
date: 2016-10-06
title: Android vulnerabilities and security
speaker: Chandler Freeman
type: Meeting
---
Come join us Thursday October 6th at 19:00EDT, as Chandler Freeman talks about Android vulnerabilities and the world of mobile security. Chandler will do a brief analysis given some newer exploits, and try to determine how widespread the vulnerabilities still are in the ecosystem. 

Did you know about Ohio Linux Fest? It's a great opportunity to learn from some great speakers and meet fellow FLOSS enthusiasts. You can register for **FREE** at https://ohiolinux.org/registration/.
