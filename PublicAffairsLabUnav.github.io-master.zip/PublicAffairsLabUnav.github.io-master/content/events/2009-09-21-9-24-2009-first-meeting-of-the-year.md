---
date: 2009-09-21
type: "Meeting"
title: First Meeting of the Year
---
This Thursday, in [Dreese Labs](http://www.osu.edu/map/building.php?building=279) room 266, we had our first meeting of the 2009/2010 school year. We have many things to do at this meeting, including drafting/revising the constitution, and discussing meeting topics for this quarter. Please note: We are located in Dreese Labs room **266**. This is not in the main part of Dreese, and easily confused with [Baker Systems and Engineering](http://www.osu.edu/map/building.php?building=280). The room is near the bridge connecting Dreese and Baker, and to the west. To get there, either enter through Dreese, cross the bridge, and turn right; or enter through Baker and turn left down the long hallway before the bridge.
