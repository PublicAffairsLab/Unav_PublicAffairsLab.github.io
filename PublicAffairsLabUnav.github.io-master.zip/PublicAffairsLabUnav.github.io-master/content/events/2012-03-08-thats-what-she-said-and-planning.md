---
date: 2012-03-08
title: That's What She Said and Planning
---
I apologize for the late meeting topic announcement, but there were some unexpected delays.

Thursday, March 8th at 7:00PM in Dreese 266 Joel Friedly will present on a project he was working on for a class.  For a lab in his Python class, he built a simple Bayes network-based text classifier to identify That's What She Said jokes in conversation transcripts. This will be added to Jenni, the Open Source Club's IRC bot, so that she can make jokes at appropriate times in conversation. It will replace the old TWSS identifier.

Additionally, we will plan for the next quarter.
