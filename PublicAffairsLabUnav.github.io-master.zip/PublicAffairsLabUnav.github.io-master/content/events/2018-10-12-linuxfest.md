---
date: 2018-10-12
title: "Linuxfest"
speaker: "The Open Source Club at The Ohio State University"
type: "Convention"
time: '0900'
location: 'Hyatt Regency'
---

This year, the sixteenth annual Ohio LinuxFest is being held October 12 - 13, 2018 at the Hyatt Regency in Columbus, Ohio. Ohio LinuxFest is the oldest and largest Linux and Open Source conference in the Midwest. In 2017, over 800 people attended LinuxFest from all over the country to learn about open source software as well as to visit our vendor booths and engage with our partners.

The Open Source Club mans a booth for the duration of the conference. To volunteer, please email the [Open Source Club Officers](mailto:opensource-officers@cse.ohio-state.edu). Otherwise, sign up as an attendee at [https://ohiolinux.com/registration/](https://ohiolinux.com/registration/). We can't wait to see you there!
