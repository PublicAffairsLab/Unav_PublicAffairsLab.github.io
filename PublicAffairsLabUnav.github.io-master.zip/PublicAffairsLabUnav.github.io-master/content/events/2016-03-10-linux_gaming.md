---
date: 2016-03-10
title: Open Source and Linux Gaming
speaker: Nikit Malkan (Nefari0uss) and William Osler (LibreWulf)
type: Meeting
---

Level up this Thursday, 2016/03/10 at 7:00pm in Caldwell Labs 120 as Nikit
Malkan and William Osler present a talk on gaming with Linux. From free software
games like 0 A.D. and Super Tux Cart to proprietary games that run with a
compatibility layer, come learn about some of the essentials for getting the
most game out of your Linux system. We'll also be covering details like how to
get set up and going in Wine, games you can run Linux servers for, game engines
with Linux support and more.

Also important this week, we'll be having registration for club voting. We're
changing up how voting is done for University compliance reasons. If you want to
be able to have a vote in future club leader or constitution changes, attending
this week's meeting is super important.

A huge thanks to everyone who helped volunteer during the OHI/O Makeathon over
the weekend. Volunteer efforts help keep our club running (and buy that pizza we
all enjoy).
