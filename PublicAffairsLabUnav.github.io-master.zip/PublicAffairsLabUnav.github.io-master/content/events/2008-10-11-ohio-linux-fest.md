---
date: 2008-10-11
type: "Convention"
title: Ohio Linux Fest
---
The Open Source Club is going together to the Ohio Linuxfest this year on
Saturday, October 11<sup>th</sup>. The first presentation is at 9:30 am. Rather
than drive/taxi, bring your Buck-ID<sup>tm</sup> and you can [ride COTA](http://www.google.com/maps?ie=UTF8&f=d&z=15&ll=39.962418,-83.00055&spn=0.01018,0.013733&saddr=1813+N+High+St,+Columbus&daddr=400+N+High+St,+Columbus&date=10-11-2008&time=9:30+am&ttype=arr&dirflg=r) for free...
