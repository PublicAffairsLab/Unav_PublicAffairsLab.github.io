---
date: 2016-09-15
title: Capital One presents trends in computing
speaker: Kapil Thangavelu
type: Meeting
---
Join us this Thursday as Kapil Thangavelu, the Data Engineering Director from Capital One, gives us an industry view of trends in computing. Topics will include big data, the cloud, and containers. Kapil will also talk about opensource projects from Capital One and why opensource is important in industry.
