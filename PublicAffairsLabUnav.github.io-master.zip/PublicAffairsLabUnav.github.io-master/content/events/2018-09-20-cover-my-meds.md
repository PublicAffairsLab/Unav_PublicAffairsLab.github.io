---
date: 2018-09-20
title: "Open Source Web Tools"
speaker: "Cover My Meds"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

This week at the Open Source Club we will be having a developer and some recruiters in from CoverMyMeds in to talk about a day in the life of a developer at CoverMyMeds and some of the open source web tools they use in their development cycle. They will be coming in with their recruiters and this would be a great opportunity to talk with them about their Co-Op Program they offer to students.

#### As always, laptops are encouraged and pizza will be provided.
