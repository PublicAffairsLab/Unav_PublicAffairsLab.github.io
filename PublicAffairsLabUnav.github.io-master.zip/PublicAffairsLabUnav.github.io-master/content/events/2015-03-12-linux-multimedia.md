---
date: 2015-03-12
title: Linux Multimedia
speaker: Brandon Dahl (riffer)
type: Meeting
---
This Thursday, 2015-03-12 at 7:00pm in Caldwell Labs 120, Brandon Dahl will present Linux Multimedia. A short description follows:

Brandon will be talking about the basics of using LMMS (Linux Multimedia Studio) to produce music. We'll go over creating tracks, combining tracks, adding FX to the tracks, automation, and mixing tracks.

Laptops are encouraged but not required, and as always, there will be pizza.
