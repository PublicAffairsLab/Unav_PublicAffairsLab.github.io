---
date: 2016-02-18
title: Intermediate Vim
speaker: Jonathan Arnett (J3RN)
type: Meeting
---

Thursday, 2016/02/18 at 7:00pm in Caldwell Labs 120

This talk is targeted at the Vim user who is looking to take their knowledge of the editor to the next level. It can take several years to master a text editor in all it's intricacies, and Vim is no exception. Having used Vim for the last four years or so, I will try to impart some of the lessons I have learned - not just about how to use Vim, but also about how to learn to use Vim. Some prior Vim experience will be beneficial.
