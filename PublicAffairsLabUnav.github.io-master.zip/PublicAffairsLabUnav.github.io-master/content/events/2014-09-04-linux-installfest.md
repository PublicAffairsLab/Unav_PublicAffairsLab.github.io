---
date: 2014-09-04
title: Linux Installfest
speaker: Chris Wallace
type: Meeting
---
Thursday, 2014-09-04 at 7pm in Caldwell Labs 120, Chris Wallace and the Open Source Club will present "Linux InstallFest". We'll be helping you to install GNU/Linux on your machines, and will be available to answer any questions you may have.

Overall, we would like you to not only have GNU/Linux installed, but also have a pretty good idea of the things you can do with it.

Laptops are always encouraged but not required, and as always, there will be pizza.
