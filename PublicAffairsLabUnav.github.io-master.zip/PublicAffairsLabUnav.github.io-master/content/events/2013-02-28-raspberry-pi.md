---
date: 2013-02-28
title: Raspberry Pi
---
This Thursday, 2013/02/28 at 7pm in Dreese Labs 369, the Ohio State Open Source Club will be presenting "Raspberry Pi: All that you can do for $35." This meeting will consist at first with a presentation by Chris Wallace into what this little guy is all about, followed by a series consisting primarily of members sharing their experiences with the Raspberry Pi, a $35 computer platform about the size of a credit card ([raspberrypi.org](http://www.raspberrypi.org/)). Come on down and check out the neat computer and hobby projects we have been up to in our spare time, and get an idea of all the possibilities out there for a computer that fits in your hand!

As always, there will be pizza.
