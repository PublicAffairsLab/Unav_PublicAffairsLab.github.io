---
date: 2015-02-26
title: Open Source and Web Browsers
speaker: Nikit Malkar (paradigm)
type: Meeting
---
Thursday, 2015-02-26 at 7:00pm in Caldwell Labs 120, Nikit Malkan (Treasurer of the Open Source Club) will present Open Source and Web Browsers. A short description follows:

For this week's meeting I will be going over Web browsers. I will talk about their many uses and perhaps some unknown features, give a brief history about the browser wars, and go over the major Web browsers of the past and present. Assuming sufficient time is left, I will end by going over my personalized Firefox setup and some of the many unique addons/features that make Firefox still worth using.

Laptops are encouraged but not required, and as always, there will be pizza.
