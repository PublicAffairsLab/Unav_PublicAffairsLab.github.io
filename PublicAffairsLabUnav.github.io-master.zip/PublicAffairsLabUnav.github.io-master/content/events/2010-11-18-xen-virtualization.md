---
date: 2010-11-18
type: "Meeting"
title: Xen Virtualization
---
On Thursday, November 18, at 7:00PM in the Ohio Union Senate Chamber, Matt Meinwald will be presenting on Xen, a popular server virtualization system.  He will show what the software has to offer and will demo the installation process on Debian. Depending on time and interest, he may explain how we use it in the Open Source club systems or compare it to other software out there.
