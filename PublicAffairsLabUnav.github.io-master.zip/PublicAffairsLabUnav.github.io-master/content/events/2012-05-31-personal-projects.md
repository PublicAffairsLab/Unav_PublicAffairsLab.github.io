---
date: 2012-05-31
title: Personal Projects
---
Thursday, May 31st at 7:00PM in Dreese 369, We will be presenting personal projects which is my favorite meeting. So come with your projects in hand and ready to show off and we will get through as many as possible.
