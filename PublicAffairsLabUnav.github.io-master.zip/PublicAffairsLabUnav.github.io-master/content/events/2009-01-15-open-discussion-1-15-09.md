---
date: 2009-01-15
type: "Meeting"
title: Open Discussion
---
Due to the bad weather we have chosen to postpone our original meeting topic for this week. There will however still be a meeting for anyone who wants to come hang out. We will be letting people suggest future topics that they would like to see (or present). As usual, the meeting will be at 7p in [Dreese Labs](http://www.osu.edu/map/building.php?building=279) 266.
