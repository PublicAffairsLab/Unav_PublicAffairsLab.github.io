---
date: 2016-11-03
title: DDWRT and OpenWRT, free your router
speaker: OSC
type: Meeting
---
Join us Thursday November 3rd, 2016 at 19:00 in Caldwell 120 to learn about DD-WRT and OpenWRT, two Linux distributions for your wireless router. You'll learn how to turn your cheap consumer router into fully-featured professional hardware with the power of open source. 
