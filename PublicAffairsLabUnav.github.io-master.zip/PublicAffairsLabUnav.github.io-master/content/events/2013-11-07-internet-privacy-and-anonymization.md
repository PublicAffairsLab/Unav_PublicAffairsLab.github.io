---
date: 2013-11-07
title: Internet Privacy and Anonymization
---
Hey everyone, sorry for the late email!

This Thursday 2013/11/07, at 7:00pm in Caldwell Labs 120 we will be discussing Internet Privacy, as well as tools that can keep you anonymous on the Internet. Topics will include Tor, Firefox Extensions, and Darknets, as well as a discussion on technical privacy.
Laptops are encouraged, and as always, there will be pizza.
