---
date: 2012-08-23
title: 'First Meeting: What is Open Source?'
---
Thursday, August 23rd at 7:00 PM in Dreese Labs room 266, The Ohio State University Open Source Club will have its first meeting of the 2012-2013 academic year. Paul Schwendenman, this year's president, will be giving an introduction to what it means for something to be Open Source- hopefully helping to explain to any potential new members what the club is really about.

As always, pizza will be provided.
