---
date: 2014-01-23
title: Distributed Version Control Systems
---
Greetings!

This Thursday, January 23rd 2014 at 7:00PM in Caldwell Labs <b>133</b> (note the change), Daniel Thau will be giving a presentation on Distributed Version Control Systems (DVCS). DVCSs are distributed systems which keep track of software revisions. These are usually, but not necessarily, used to manage programming projects. Daniel will go over the idea behind a DVCS, as well as some of the stuff going on under the hood in one of them (git).

Laptops are encouraged, but not required, and as always, there will be pizza.
