---
date: 2010-11-21
type: "Meeting"
title: No Meeting this Week
---
Due to the Thanksgiving holiday on Thursday, we will not have a meeting this week. The next meeting is December 2, and will be about Vim and planning for next quarter.
