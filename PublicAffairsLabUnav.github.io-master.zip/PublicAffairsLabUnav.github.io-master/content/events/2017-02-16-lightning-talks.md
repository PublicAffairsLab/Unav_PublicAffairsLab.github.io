---
date: 2017-02-16
title: "Lightning Talks"
speaker: Various Club Members
type: "Meeting"
---

Join us Thursday February 16 at 19:00 with your short talks on technology to present to the club. Talks should be between 5 and 10 minutes on a topic that you find fascinating. Previous lightning talks have included version control, OpenSCAD, Linux MultiMedia Studio, and gaming on Linux. Be creative and be supprotive to those presenting.
