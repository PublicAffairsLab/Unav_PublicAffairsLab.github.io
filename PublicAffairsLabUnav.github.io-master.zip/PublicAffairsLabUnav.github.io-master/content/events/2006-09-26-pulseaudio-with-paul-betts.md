---
date: 2006-09-26
type: "Meeting"
title: PulseAudio with Paul Betts
---
Room: 480 Dreese Labs  

Paul gave a great presentation on PulseAudio, the new sound server that will
officially make its debut in GNOME `2.18`. As a special treat, Alex gave a preview
of Peter's upcoming Net Neutrality meeting, explaining that the Internet is not
a dump truck, but really a series of tubes.

<!--FIXME-->
<!-- [![](/sites/default/files/DSCF5003.thumbnail.JPG)](/sites/default/files/DSCF5003.JPG "Alex explains the inner working of the Internet backbone, or "tubes", to an enthralled audience.")

[![](/sites/default/files/DSCF5004.thumbnail.JPG)](/sites/default/files/DSCF5004.JPG "Here is a more detailed picture of the "tubes." Notice that Senator Steven's internets were sent on Friday, and were received "today". Obviously this is a problem.")

[![](/sites/default/files/DSCF5005.thumbnail.JPG)](/sites/default/files/DSCF5005.JPG "Here is a photograph of the right side of the board. The "tube" at the bottom is being cleared with race horses and lottery balls. Also, the Internet is not a duck.") -->
