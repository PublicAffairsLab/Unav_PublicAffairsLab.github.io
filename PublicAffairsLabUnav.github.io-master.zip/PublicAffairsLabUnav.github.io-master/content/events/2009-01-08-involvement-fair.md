---
date: 2009-01-08
type: "Convention"
title: Involvement Fair
---
The Open Source Club is going to be at the [2009 Winter Involvement Fair](http://ohiounion.osu.edu/studentorgs/events_winter_involvement.asp) in the lobby of [Knowlton Hall](http://www.osu.edu/map/building.php?building=017) this Thursday [1/8]. Therefor there will be no meeting this week. But feel free to stop by the involvement fair if you want to chat with us!
