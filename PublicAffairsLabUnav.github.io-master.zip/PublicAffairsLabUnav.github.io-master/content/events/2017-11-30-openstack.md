---
date: 2017-11-30
title: "Developing OpenStack"
speaker: "David Stanek"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

This presentation will talk about a few of the challenges that David saw while working in the OpenStack community. For each challenge he wants to talk about how the issues were mitigated. There will be a heavy focus on the development process.

This is our last meeting of the semester, and we will discuss several changes that we are going to undertake over Winter Break and going into next semester.
