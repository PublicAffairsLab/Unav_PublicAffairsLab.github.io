---
date: 2014-11-13
title: Web Privacy
speaker: OSC
type: Meeting
---
Thursday 2014/11/13, at 7:00pm in Caldwell Labs 120 we will be discussing Internet Privacy, as well as tools that can keep you anonymous on the Internet. Topics will include Tor, Firefox Extensions, and Darknets, as well as a discussion on technical privacy.

Laptops are encouraged but not required, and as always, there will be pizza.
