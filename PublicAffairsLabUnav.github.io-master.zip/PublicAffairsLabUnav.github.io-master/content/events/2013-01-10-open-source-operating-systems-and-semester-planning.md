---
date: 2013-01-10
title: Open Source Operating Systems and Semester Planning
---
This week, Thursday 2013/01/10 at 7pm in Dreese 369, The Ohio State University Open Source Club will be presenting Free and Open Source Operating Systems- An Overview, introduction, and discussion. Members of the club will present different open source operating systems, with the end goal of making everyone more knowledgeable on the variety of distributions out there.

If you don't use Linux, BSD, or otherwise, this could be the time to see where your interests are, and what works for you!

If anybody would like to speak about their operating system of choice, please send me an email at wallace.586@osu.edu

In addition to our presentation, a discussion will also be held to seek out ideas for future meetings in the semester.
