---
date: 2006-10-25
type: "Meeting"
title: The Internet is Burning...
---
...atleast our mailing list has caught fire.


Who would have thought "Linux vs. Windows" would have drawn any attention? I just want to rehash a comment made during our latest meeting "This week in slashdot" where +5 points was awarded for mentioning that "the Internet is not a drug"...


I believe there was a joke in there, something about doing something for coke...
