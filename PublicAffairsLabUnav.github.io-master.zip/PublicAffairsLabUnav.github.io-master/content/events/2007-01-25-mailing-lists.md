---
date: 2007-01-25
type: "Meeting"
title: Mailing Lists
---
We have two mailing lists: A discussion mailing list and an announcements-only
mailing list. Announcements are sent to both so you will most likely want to
subscribe only to one or the other. If you are in the department of CS&E at OSU
you can also participate on the discussion list via the **cse.opensource**
newsgroup:

- [OpenSource Discussion](http://mail.cse.ohio-state.edu/mailman/listinfo/opensource)
- [OpenSource Announce](http://mail.cse.ohio-state.edu/mailman/listinfo/opensource-announce)
