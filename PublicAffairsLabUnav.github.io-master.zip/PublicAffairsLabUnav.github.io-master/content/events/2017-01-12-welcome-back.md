---
date: 2017-01-12
title: "Welcome Back"
speaker: "Brandon 'Bam' Moore (malide)"
type: "Meeting"
---

Join us on January 12th, 2017 at 19:00 in Caldwell 120 as we discuss the upcoming semester and how to contribute to open source.
