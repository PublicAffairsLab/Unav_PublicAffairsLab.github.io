---
date: 2013-02-21
title: Willie the IRC bot
---
This Thursday, 2013/02/21 at 7pm in Dreese Labs 369, Edward Powell will be presenting on the Willie IRC bot. The bot has all sorts of cool features, like the ability to retrieve your time and weather, or the upvotes on a Reddit post, all from within an IRC channel. Even better, it's designed to make it easy for you to write your own features, with a simple and featureful API. Both the API and the included features will be covered, along with some information about how the bot works behind the scenes.

As always, there will be pizza.
