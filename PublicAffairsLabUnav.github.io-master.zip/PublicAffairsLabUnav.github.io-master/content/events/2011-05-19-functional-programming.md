---
date: 2011-05-19
title: Functional Programming
---
Have you ever wondered what functional programming is all about or how to use funky languages people are always talking about? This Thursday, May 19 at 7PM in Dreese 264, Alex Burkhart will describe the basic concept of functional programming and introduce us to Haskell. Next, Silas Baronda will present Erlang.
