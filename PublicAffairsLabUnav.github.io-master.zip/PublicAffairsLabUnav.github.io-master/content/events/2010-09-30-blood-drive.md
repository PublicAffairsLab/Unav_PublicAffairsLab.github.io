---
date: 2010-09-30
type: "Meeting"
title: Blood Drive
---
This Thursday, September 30 from 12-6PM, we are sponsoring a Red Cross blood drive in Dreese Lab.  If you would like to schedule a time to donate blood between 12PM and 6PM, you would like to help at the table between 11AM and 7PM, or if you have any questions, please contact Matt Meinwald (meinwald.1@osu.edu).
