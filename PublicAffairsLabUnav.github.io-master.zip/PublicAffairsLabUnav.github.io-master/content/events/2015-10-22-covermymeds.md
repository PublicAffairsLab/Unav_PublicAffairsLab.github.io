---
date: 2015-10-22
title: Working in a Production Environment
speaker: Jay Bobo and Vasanth Pappu from CoverMyMeds
type: Meeting
---

Hi everyone,

This Thursday at 7:00PM in Caldwell Labs 120, Jay Bobo and Vasanth Pappu from CoverMyMeds will discuss what it's like working in a production environment. For those that are unfamiliar, CoverMyMeds is a Columbus startup that automates the Prior Authorization process in the healthcare industry. I urge everyone to go check them out!
 
Laptops are encouraged but not required, and as always, there will be pizza.
