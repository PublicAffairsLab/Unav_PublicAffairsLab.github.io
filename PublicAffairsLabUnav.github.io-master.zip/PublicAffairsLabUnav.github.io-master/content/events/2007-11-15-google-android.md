---
date: 2007-11-15
type: "Meeting"
title: Google Android
---
Our last meeting (Nov 15) was about the Open Handset Alliance's Android. A
mobile operation system and application stack. We had a demo with the Hello
World and spent a lot of the time playing with the emulator prototype. Because
I feel this is a very interesting development, I personally will be working on
creating some apps for the platform. In addition, Google has $10M in prizes for
developers who create interesting new applications for this platform.

<iframe width="560" height="315" src="https://www.youtube.com/embed/6rYozIZOgDk" frameborder="0" allowfullscreen></iframe>
