---
date: 2016-01-14
title: Welcome Back
speaker: Eli Gladman
type: Meeting
---
This Thursday, January 14th at 7PM in Caldwell 120, we will be voting on whether
or not to amend our club's constitution. So for that reason, I encourage everyones'
attendance.
