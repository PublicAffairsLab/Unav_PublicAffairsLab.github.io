---
date: 2018-04-12
title: "Reclaim Your Privacy"
speaker: "Christopher `brainblasted` Davis"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

This week, Christopher `brainblasted` Davis will be giving a talk on how to reclaim your privacy with free software on the internet.

#### As always, laptops are encouraged and pizza will be provided.
