---
date: 2012-09-22
title: Autumn LAN Party
type: Party
---
Good news everyone!

This Saturday, September 22 2012, from 12:00pm - 10:00pm in the Ohio Union Interfaith Prayer and Reflection Room, The Ohio State Open Source Club will present it's first LAN Party of the autumn semester. Come out and join, meeting Open Source Club members and playing games (both open and closed source). The games include:

- Minecraft
- Team Fortress 2
- Counter-Strike
- Starcraft (I / II)
- Warsow
- Teeworlds

... and anything else that we decide while we are there!

Additionally, there is no cost for admission, you just need to bring your own computer. I personally hope to see everyone there!
