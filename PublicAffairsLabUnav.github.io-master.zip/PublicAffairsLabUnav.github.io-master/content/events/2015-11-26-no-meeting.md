---
date: 2015-11-26
title: Network Maintenance and Upgrades
speaker: William Osler (LibreWulf)
type: Internal
---

The club systems will be undergoing scheduled maintenance this weekend, so expect downtime. Our sysadmin, William, will be reverting [Gluster](https://www.gluster.org/). Also, We will be upgrading Stallman's ram from 4GB ram to 12GB, in addition to replacing the power supply.
