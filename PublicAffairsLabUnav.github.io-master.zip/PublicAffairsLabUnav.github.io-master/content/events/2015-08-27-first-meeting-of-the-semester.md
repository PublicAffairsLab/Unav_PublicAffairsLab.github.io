---
date: 2015-08-27
title: First Meeting of the Semester
speaker: Eli Gladman
type: Meeting
---
This Thursday, 2015/08/27 at 7:00PM in Caldwell Labs 120, Eli Gladman and the Open Source Club will present our very first meeting of the 2015-2016 academic year.

This meeting, geared toward beginners, gives an overview of the club including what we do and why we care. Additionally, this meeting is more social in nature with plenty of time to meet new people and network around.
