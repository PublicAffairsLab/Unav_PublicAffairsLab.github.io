---
date: 2015-03-09
title: System Updates
speaker: OSC
type: Internal
---
Update on the stallman2 migration:

It's happening! The largest of the remaining tasks has been completed and we're almost all set to go. Downtime will be scheduled this Friday starting at 3pm until I have no clue when as we do a final sync of the data, physically move the hardware, and verify that everything is operating correctly.

Since stallman2 is a fresh start, it may not have all the software that stallman currently has. I'll try to install some commonly used software, but if there's something specific you want please email me at osler.6 to request it. Especially if you'd like a DE other than Unity or i3, since that's all that's installed so far.

Please note that the new machine will be Ubuntu 14.04 (from 12.04) and will be 64 bit (from 32 bit).
