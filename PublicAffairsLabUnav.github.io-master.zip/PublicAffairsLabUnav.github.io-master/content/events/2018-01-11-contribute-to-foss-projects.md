---
date: 2018-01-11
title: "Contribute to FOSS Projects"
speaker: "Chris `brainblasted` Davis"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

This week, we'll be talking about how to get started contributing to FOSS projects. This should cover any skill level, so even if you've never made a "Hello World" you should come away having learned how to help out with your favorite projects. It will be this Thursday, 7:30 p.m. at CL 120.

As always, laptops are encouraged and pizza will be provided.
