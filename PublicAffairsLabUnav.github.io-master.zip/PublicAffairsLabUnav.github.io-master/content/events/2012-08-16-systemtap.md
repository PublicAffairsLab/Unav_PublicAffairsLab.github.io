---
date: 2012-08-16
title: SystemTap
---
[SystemTap](http://sourceware.org/systemtap/) is a scripting language for your kernel. It allows for profiling or otherwise analyzing a running system, both at the kernel and userspace levels. I will start my talk by reviewing some of the other profiling and debugging tools available on a Linux system, then will illustrate how SystemTap can do all of that and a whole lot more.
