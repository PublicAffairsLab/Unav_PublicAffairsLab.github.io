---
date: 2015-10-10
title: Engineering Homecoming Tailgate
speaker: OSC
type: Volunteer
---

Come volunteer at the Engineering Homecoming Tailgate.

- Date: Saturday, October 10th, 2015
- Where: Knowlton Hall Plaza
- Time: 9-11am

Various shifts needed from 7 am-12pm



Positions:

- event setup/cleanup
- greeters
- food & beverage line attendants
- registration staff
- trivia competition assistants
