---
date: 2010-11-04
type: "Meeting"
title: Model View Controllers
---
This Thursday, November 4th at 7PM in the Ohio Union Senate Chamber, Jonathan Tubb will be giving an overview of Model View Controllers. A popular architecture for developing web applications, MVCs have come into their own in the past decade becoming the standard for quick deployment of applications. Information, use cases, and examples of MVCs and web applications will be covered.

Also featuring Tubbs witty remarks and dashing good looks, maybe even pizza.
