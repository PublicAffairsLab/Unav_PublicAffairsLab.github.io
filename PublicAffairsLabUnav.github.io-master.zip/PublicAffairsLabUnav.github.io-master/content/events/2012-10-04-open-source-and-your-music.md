---
date: 2012-10-04
title: Open Source and Your Music
---
Hello everyone!

This Thursday, October 4th, at 7pm in Dreese Labs 264, Chris Wallace will be presenting "Open Source and Your Music."

The presentation should cover:
- Media Players
- Audio Formats
- Music Management
- Licensing Issues

... and more!

As always, there will be pizza.
