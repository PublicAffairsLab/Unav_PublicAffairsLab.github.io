---
date: 2015-01-15
title: Welcome Back
speaker: OSC
type: Meeting
---
This Thursday, 2015/01/15 at 7:00pm in Caldwell Labs 120, The Open Source Club will present "Welcome Back". We'll be around to socialize and plan the upcoming meetings.
