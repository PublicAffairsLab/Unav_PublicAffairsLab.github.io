---
date: 2016-08-25
title: Welcome To Open Source
speaker: "Brandon 'Bam' Moore (malide)"
type: Meeting
---
Come join us August 25th at 19:00 in Caldwell 120 to learn what Open Source is and why you should use it. You'll meet our officers for the year, and there will be plenty of time for socializing and eating pizza!
