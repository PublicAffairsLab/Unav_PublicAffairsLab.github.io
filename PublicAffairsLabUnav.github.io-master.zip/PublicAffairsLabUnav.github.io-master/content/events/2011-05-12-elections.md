---
date: 2011-05-12
title: Elections
---
Club elections will be held May 12, 2011. If you are interested in running, please email elections@opensource.osu.edu in order to be listed here and in the meeting announcement. Any OSU student who has been to at least one meeting is eligible to run for president, vice president, or treasurer.

The following people have announced their candidacy.

President: Daniel Thau
Vice President: Paul Schwendenman, Brian Swaney (tentative)
Treasurer: Joel Friedly

In addition, Brian Swaney has proposed the following ballot initiative.

With most discussion surrounding ACTA/COCIA/SHIELD and Wikileaks ex post facto legislation died down, the immediate urgency with which it was hastily voted on and posted is alleviated. The senator who introduced the Espionage amendment (SHIELD Act, by John Ensign R-NV) which sparked this movement is also no longer in office, although a key co-sponsor Joe Lieberman I-CT is still in office. Therefore, during the election procedure I believe we should also vote on its removal. While the Open Source Club will continue its endorsement of EFF, it no longer seems necessary to keep extra clutter on our web page. <em>Shall the Ohio State University Open Source Club remove the Electronic Frontier Foundation's "Say NO to online censorship" button?</em>
