---
date: 2009-10-11
type: "Meeting"
title: Mobile Software Development Forum
---
On Thursday November 12th, 2009, we will be hosting a discussion on the merits, ideologies, pros, cons, and whatever else that can be discussed about mobile software development.  WebKit, Android, Midp, and etc are all fair game for discussion so bring your questions, rants, and raves to the meeting so we can all have a nice old fashioned forum discussion.
