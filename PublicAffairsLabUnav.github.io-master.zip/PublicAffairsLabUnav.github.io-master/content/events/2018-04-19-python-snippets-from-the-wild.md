---
date: 2018-04-19
title: "Python, Snippets from the Wild"
speaker: "Andrew `smacz` Cziryak"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

This week smacz will presenting a talk called "Python: Snippets from the Wild", where he goes over several snippets of his Python code that are running in production today. This is meant to spur discussion both about the implementation, and in what context the code is being used.

This is also the last meeting of the semester! There will be a brief and informal retrospective on the year, and a discussion on what to expect over the summer and in the semesters to come.

#### As always, laptops are encouraged and pizza will be provided.
