---
date: 2008-03-03
type: "Meeting"
title: Hacking the Wiimote
---
Last week, we had a really good turnout and watched some demos of [hacking the Nintendo Wii remote](http://www.usmechatronics.com/usmgarage/WiiBot.html)
to create your own virtual 3-D environment in relative to your perspective,
along with a few other slick [multi-touch-screen interfaces](http://www.ted.com/index.php/talks/view/id/65),
bordering on making keyboards obsolete. We had a really great turnout and are
considering doing it in the future. More information is yet to come... There is
also some talk about hacking the new [Eee](http://en.wikipedia.org/wiki/ASUS_Eee_PCEEE "ASUS Eee PC - Wikipedia, the free encyclopedia"),
a $500 child-sized laptop similar to the [OX](http://laptop.org/laptop/ "One Laptop per Child")
(One Laptop per Child campaign) with Linux pre-installed that, for the price,
has some pretty impressive hardware specs, and I might add it is very light-weight.
