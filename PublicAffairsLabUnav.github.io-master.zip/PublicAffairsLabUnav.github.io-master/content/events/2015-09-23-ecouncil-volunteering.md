---
date: 2015-09-23
title: Engineering Expo Career Fair
speaker: OSC
type: Volunteer
---

Please consider volunteering for the Engineering Expo Career Fair on September 22nd & 23rd on behalf of the Open Source Club. If you are interested [sign up here](http://www.signupgenius.com/go/20f0e4aa8a92ba0fc1-engineering1)
