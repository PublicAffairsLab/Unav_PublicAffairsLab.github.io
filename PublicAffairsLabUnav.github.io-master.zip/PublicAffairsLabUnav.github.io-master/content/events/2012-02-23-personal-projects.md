---
date: 2012-02-23
title: Personal Projects
---
Thursday, February 23rd at 7:00PM in Dreese 266 various club members will be presenting personal projects. If you're working on anything, feel free to bring it in to show off!
