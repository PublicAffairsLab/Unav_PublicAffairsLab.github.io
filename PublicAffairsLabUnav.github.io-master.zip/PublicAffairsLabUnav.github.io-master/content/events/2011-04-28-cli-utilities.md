---
date: 2011-04-28
title: CLI Utilities
---
On Thursday, April 28, at 7PM in Dreese 264, we will have lightning talks about programs with a command-line interface (CLI). These utilities can be useful in their own right, but often can be connected together with pipes to do new and interesting things. It would be helpful if people interested in presenting signed up with their choices, either by emailing me at meinwald.1@osu.edu or commenting below. This way we can avoid duplication. For now assume each talk can be up to 5 minutes, but that is subject to change.

So far the following people have signed up.

Dan Thau: awk, clive, busybox, graft, pwd, whoami
Morgan Goose: netcat, tar, rsync, iperf, tee
Matt Meinwald: curl, wget
Alek Rollyson: tshark, offlineimap, slock, packer, gnupg, rtorrent
