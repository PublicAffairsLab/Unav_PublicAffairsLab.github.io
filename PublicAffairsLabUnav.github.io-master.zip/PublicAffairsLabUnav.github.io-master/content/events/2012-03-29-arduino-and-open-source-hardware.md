---
date: 2012-03-29
title: Arduino and Open Source Hardware
---
THIS WEEK IN OPEN SOURCE!:

Ryan Karason will be teaching on open source hardware. The purpose of the lecture is to discuss the basic principles of electricity as applied to circuitry and to introduce the open hardware prototyping platform created by Arduino. If you are interested in getting involved in making your own circuits or better understanding others' circuits so you can hack them, show up this Thursday; March 29, 1012 at 7PM in 266 Dreese Laboratory.
