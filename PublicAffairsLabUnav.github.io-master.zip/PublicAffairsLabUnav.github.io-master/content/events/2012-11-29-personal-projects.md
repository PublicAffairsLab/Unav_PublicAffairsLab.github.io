---
date: 2012-11-29
title: Personal Projects
---
Hello everyone!

This Thursday, November 29 at 7:00pm in Dreese Labs 266, The Ohio State University Open Source Club will present "Personal Projects."

This talk will have members of the club giving small bits on what they are doing in their spare time. If you have interest in speaking, please email me  at wallace.586@osu.edu with your topic.

Talks will be limited to 5 minutes at a time, with the hope of getting to everyone with interest in speaking to have their time. After everyone has finished, people will have the opportunity to revisit topics and ask questions.
