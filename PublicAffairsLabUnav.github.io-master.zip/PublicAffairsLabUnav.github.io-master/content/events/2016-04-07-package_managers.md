---
date: 2016-04-07
title: Package managers and Open Source election
speaker: "Brandon 'Bam' Moore (malide)"
type: Meeting
---
Thursday, 2016/04/07 at 7:00PM in Caldwell Labs 120

This Thursday, Brandon Moore will present on package managers. From distro-based package managers to project-based package managers, we will discuss what a package manager is, the advantages and disadvantages of package managers, the recent issue with the mass-unpublishing of Node modules, and more.

Don't forget that the election will also occur at this meeting. If you haven't registered to vote yet then please get in contact with the officers. If you'd like to run for a position, please get in contact with the officers.
