---
date: 2014-01-30
title: Resume Review
---
Hello!

This Thursday, January 30th at 7pm in Caldwell Labs 120, the Open Source Club will hold a resume review session with Brooksource. Bring your resume for an opportunity to get it read by recruiters to make sure you are ready for the S.W.E. career fair this Wednesday, February 5th. There will be gift cards and as always, there will be pizza. Brooksource is a firm specializing in project and supplemental support through contract employment, contract-to-hire labor employment, and direct placements.
