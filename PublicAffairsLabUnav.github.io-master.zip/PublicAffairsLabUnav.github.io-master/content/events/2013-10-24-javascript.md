---
date: 2013-10-24
title: JavaScript
---
This Thursday, 2013/24/10 at 7:00pm in Caldwell Labs 120, Maxim Kim will be presenting JavaScript. This will be about 40 min long. It will be a high level overview of the language with some examples covering both server and client side. Slides can be found [here](http://slid.es/maximkim/deck/).

As always, there will be pizza.
