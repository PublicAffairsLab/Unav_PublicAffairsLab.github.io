---
date: 2014-08-28
title: What is Open Source?
speaker: OSC
type: Meeting
---
Thursday, 2014-08-28 at 7:00pm in Caldwell Labs (CL) 120, Chris Wallace and the Open Source Club will present our very first meeting of the 2014-2015 academic year, titled "What is Open Source".

This meeting, geared toward beginners, gives an overview of the club including what we do and why we care. Additionally, this meeting is more social in nature with plenty of time to meet new people and network around.

Laptops are encouraged but not required, and as always, there will be pizza.
