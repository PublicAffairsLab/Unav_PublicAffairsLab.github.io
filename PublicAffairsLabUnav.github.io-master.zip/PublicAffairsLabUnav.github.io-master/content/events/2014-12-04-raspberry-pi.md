---
date: 2014-12-04
title: Raspberry Pi
speaker: OSC
type: Meeting
---
This Thursday, 2014/12/04 at 7:00pm in Caldwell Labs 120, The Open Source Club will present "Raspberry Pi". Come by to learn all about the board and it's alternatives, or just check out the cool projects club members have been working on. If you yourself have done something interesting with your pi, show it off!

This will be our last meeting of the Autumn 2014 semester. As per usual, we will do a goodbye to graduating seniors at the beginning of the meeting.
