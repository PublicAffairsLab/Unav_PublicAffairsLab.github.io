---
date: 2014-02-13
title: Init Discussions
---
This Thursday, 2014/02/13 at 7:00pm in Caldwell Labs 120, The Open Source Club will have a discussion on Init Systems.

Init systems play an important role in starting modern unix-like operating systems, and recently they have been a point of discussion in the communities surrounding Linux distributions like debian.

Laptops are encouraged but not required and as always, there will be pizza.
