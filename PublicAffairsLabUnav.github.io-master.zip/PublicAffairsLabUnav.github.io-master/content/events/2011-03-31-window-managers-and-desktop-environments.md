---
date: 2011-03-31
title: Window Managers and Desktop Environments
---
This Thursday, March 31 at 7PM in Dreese 264 we will see presentations on window managers and desktop environments. Dan Thau will show the window managers dwm and Openbox as well as LXDE which uses the latter. Mike Yanovich will demonstrate the Awesome window manager and Gnome desktop environment (version 2.x). Alek Rollyson will present Window Manager From Scratch. Alex Lingo will talk about KDE. Mike Bettencourt will introduce Gnome 3. Matt Meinwald will explain the XFCE desktop environment and Compiz.

Note that the order will likely be different than the one above. Hopefully by the end of the meeting, everyone will know enough about window managers to choose the one(s) that suit them best.
