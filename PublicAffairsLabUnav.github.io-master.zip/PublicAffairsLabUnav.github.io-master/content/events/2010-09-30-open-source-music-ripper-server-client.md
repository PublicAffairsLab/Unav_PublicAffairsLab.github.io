---
date: 2010-09-30
type: "Meeting"
title: Open Source Music Ripper / Server / Client
created: 1285605899
---
This Thursday, at 7 pm in the Ohio Union Senate Chamber, Matt Smith will be demonstrating an Open Music Server that he has been working on. It might seem too easy and obvious to bother with in this day and age. We all know how to rip CD's, collect and share music, and move it to our portables for on-the-go music. My server comes from an audiophile standpoint. Long story short, I used to sell expensive stereo equipment. There are people out there right now spending up to $60,000 on CD players. I'd like to show you how to build your own that competes with these on sound quality, is easier to use, much more fun, has more features, and is completely free. edit: my blog: http://opensourceaudiophile.com/

[Minutes](/~paradigm/minutes.html#htoc13) for this meeting (provided by the VP).
