---
date: 2017-03-06
title: "Spring 2017 Open Source Club Officer Elections"
speaker: OSC
type: "Announcement"
---
Want to get more involved with OpenSource Club? Consider running for an officer position March 9th. Positions up for reelection are:
- President
- Vice President
- Treasurer
- SysAdmin
- more as needed
If you'd like more information on what these positions feel free to email <president@opensource.osu.edu> to ask the outgoing president about how the club runs.
