---
date: 2011-11-17
title: Open Source Multiplayer Games
---
This week I will be demonstrating several open source multiplayer games we will be playing at our LAN party on Saturday!

I will be doing live demonstrations on live severs we will use for the event, so feel free to install the games on your laptop and join me in-game.

Here is a short list of the games we will be playing. This list will likely change up until the LAN party.

#### Games

- Warsow
- World of Padman
- Tremulous
- Armagetron
- Scorched3D
- BZFlag
- Teeworlds
- Freedoom

Hope to see everyone there!

-- Lingo
