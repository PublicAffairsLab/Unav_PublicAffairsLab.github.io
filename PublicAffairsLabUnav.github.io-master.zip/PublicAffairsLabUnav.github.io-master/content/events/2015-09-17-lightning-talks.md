---
date: 2015-09-17
title: Lightning Talks
speaker: Various Club Members
type: Meeting
---

Hi everyone,

This Thursday, 2015/09/17 at 7:00PM in Caldwell Labs 120, we will be holding lightning talks. For the uninitiated, lightning talks are brief presentations given by YOU. Talks are given in succession and can vary in subject matter. To get the ball rolling, I will demo Docker, a way to package your applications. I encourage everyone to present something that they're passionate about.
