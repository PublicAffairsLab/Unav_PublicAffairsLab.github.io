---
date: 2018-08-23
title: "Introduction to Open Source"
speaker: "Andrew `smacz` Cziryak, Jack `jmoore` Moore"
type: "Meeting"
time: '19:30'
location: 'Caldwell 120'
---

This week we will be having our first meeting of the year, where we go over - in detail - "What is Open Source".

#### As always, laptops are encouraged and pizza will be provided.
