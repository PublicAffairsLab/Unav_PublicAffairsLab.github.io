---
date: 2010-12-05
type: "Meeting"
title: Finals and Winter Break
---
The week of December 3 is final exams, so we will not be meeting. In addition, the next few weeks are winter break, so our next meeting is Thursday, January 10 at 7 PM. The topic and location are currently unknown. During this break, our [irc channel](/irc) and [mailing list](http://mail.cse.ohio-state.edu/mailman/listinfo/opensource) should still be active and many will be working on projects, [some of which](/git) are hosted on our website. Hopefully everyone has an enjoyable break, and we'll see you next quarter.
