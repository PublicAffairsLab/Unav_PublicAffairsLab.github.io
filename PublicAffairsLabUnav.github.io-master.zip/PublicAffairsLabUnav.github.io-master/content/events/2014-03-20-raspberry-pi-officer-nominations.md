---
date: 2014-03-20
title: Raspberry Pi / Officer Nominations
---
This Thursday, 2014/03/20 at 7pm in Caldwell Labs (CL) 120, the Open Source Club will present Raspberry Pi, the arm powered $35 computer, available online and also at micro center.

This talk will cover getting started from scratch with the pi, and then we'll dive into what club members have done with theirs.

Additionally, we will process officer nominations this meeting! Anyone interested in running for one of our positions (President / VP / Treasurer) should come to this meeting to get more information about the positions and what we do. Historically, we also have created positions in the past for things, so if you have an awesome idea or want to help out administering our systems let us know.
