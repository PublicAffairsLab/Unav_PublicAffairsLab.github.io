---
date: 2010-09-23
type: "Meeting"
title: Overview of free desktop operating systems
---
Thursday, September 23 is the first meeting of autumn quarter. We will be meeting in the Ohio Union Senate Room (note the change in location from last year) at 7PM. After a short introduction of the club and a brief description of the blood drive we are sponsoring on the 30th, Matt Meinwald will present an overview of Free operating systems, focusing primarily on GNU/Linux distributions. The main software component of a computer is its operating system, and it is good to know we have plenty of Free and Open Source options for this important role. Matt will discuss and demo popular desktop GNU/Linux distributions such as Ubuntu, Fedora, Debian, Mandriva, and OpenSuse, then if time remains, will open discussion to anyone who wishes to talk about his/her favorite distribution. As it turned out, most everyone already knew about these topics, so we discussed what the club does and future meeitngs instead of the original topic. [Minutes](/~paradigm/minutes.html#htoc7) for this meeting
