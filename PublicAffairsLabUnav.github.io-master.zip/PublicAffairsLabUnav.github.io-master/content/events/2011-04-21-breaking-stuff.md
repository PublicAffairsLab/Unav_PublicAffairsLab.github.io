---
date: 2011-04-21
title: Breaking Stuff
---
Have you ever run "rm -rf" on the wrong directory, ran "rsync" the wrong way, observed unintended consequences with "find," or locked yourself out of your own computer? If you can answer yes to any of these and would like to know what else to avoid, or if you can't and would like to keep it that way, please join us as various club members present how to break things! Everyone who has a story or a deadly command, please come and share it with us, no prior approval needed. Everyone else, prepare to be entertained.

As usual, we will be meeting on Thursday at 7PM in Dreese 264.
