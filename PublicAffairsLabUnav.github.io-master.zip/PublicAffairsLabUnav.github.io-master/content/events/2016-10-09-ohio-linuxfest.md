---
date: 2016-10-09
title: Ohio LinuxFest
speaker: OSC
type: Convention
---
Come join us today and tomorrow to enjoy Ohio LinuxFest. It's a great opportunity to both learn about Open Source Software and meet other members of the Open Source community. Open Source club will be there at the Open Source Club booth around 1600EDT and we'd love to see you guys stop by to say hello!
