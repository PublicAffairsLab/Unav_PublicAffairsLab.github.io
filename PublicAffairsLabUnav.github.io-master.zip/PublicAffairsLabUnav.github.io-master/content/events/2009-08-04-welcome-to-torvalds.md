---
date: 2009-08-04
type: "Meeting"
title: Welcome to Torvalds!
---
Welcome to our new server, Torvalds. Everything should be as it was on the old
website (as of 8/4/09) except for a newer, hopefully less buggy version of
Drupal. Enjoy!
