---
date: 2008-11-20
type: "Meeting"
title: This Week in Slashdot
---
This Thursday, November 20th, for the first time in over a year, Alex is doing
*This Week in Slashdot*. Prior knowledge of Slashdot or familiarity with current
events are not required. Random discussion is encouraged. Meeting location is
[Dreese Labs](http://www.osu.edu/map/building.php?building=279) room 266.
