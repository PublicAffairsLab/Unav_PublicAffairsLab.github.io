---
date: 2010-04-27
type: "Meeting"
title: ShellCoding
---
This Thursday, May 27th at 7:30PM in Dreese Labs 305, Jon Tubb will be talking about [ShellCoding](http://en.wikipedia.org/wiki/Shellcode) and other subversion methods. Delve into the magical world of assembly as we explore the inner workings of your favorite software and then make it do your bidding. Botnets, wireless hacking, and everything else you need to get started will be presented. **_**This meeting is provided for informational purposes only and using these techniques on equipment that is not owned by the tester is not condoned by the Open Source Club._**
