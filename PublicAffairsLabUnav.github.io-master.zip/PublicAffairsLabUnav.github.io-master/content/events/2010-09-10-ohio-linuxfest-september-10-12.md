---
date: 2010-09-10
type: "Convention"
title: Ohio Linuxfest September 10-12
---
[Ohio Linuxfest](http://ohiolinux.org/) starts this Friday, September 10 at the [Greater Columbus Convention Center](http://www.columbusconventions.com/directionsandmaps.php). Various events occur that day, but the main part of the conference is [Saturday](http://ohiolinux.org/sat10-schedule.html), which consists of talks from 9am to 7:30pm and an expo with many Linux-related organizations. The Open Source club has a table at the expo, so please stop by.
