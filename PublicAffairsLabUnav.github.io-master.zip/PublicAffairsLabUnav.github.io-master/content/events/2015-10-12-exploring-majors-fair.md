---
date: 2015-10-12
title: Exploring Majors Fair
speaker: OSC
type: Volunteer
---

Come volunteer at the Exploring Majors Fair.

- Date: Monday, October 12th, 2015
- Where: Physics Research Building
- Time: 11am-2pm



Volunteers needed:

- Shift 1: 11am-12:30
- Shift 2: 12:30-3pm



They are seeking volunteers in the following majors/pre-majors:

- Chemical Engineering
- Mechanical Engineering
- Aerospace


They need two volunteers from each department for each shift (a total of 12 volunteer slots)
