---
date: 2010-03-04
type: "Meeting"
title: Maximizing Battery Life in Linux
---
Thursday March 4<sup>th</sup>, at 7PM in [Dreese Labs](http://www.osu.edu/map/building.php?building=279) room 266, Dan Thau will be showing us how to maximize your laptop's battery life in Linux. You may be wondering once you made the switch from Windows or Mac why your laptop hasn't been lasting as long without power. Dan will be showing common battery stretching techniques as well as some extreme measures you can take in order to get the most out of your laptop battery.
