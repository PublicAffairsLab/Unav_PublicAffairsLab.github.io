---
date: 2008-04-10
type: "Meeting"
title: Code Version Managment
---
We are meeting Thursday, April 10th, at 7:00 in Dreese Labs room 266. The topic
for our meeting is source code version control, and what works best for, and
there has already been much traffic over this on our [mailing list](http://mail.cse.ohio-state.edu/pipermail/opensource/2008-April/thread.html).
Subtopics so far include [bitkeeper](http://www.bitkeeper.com/), [cvs](http://ximbiot.com/cvs/wiki/),
[git](http://git.or.cz/), [Google Code](http://code.google.com/hosting/), [Mercurial](http://www.selenic.com/mercurial/wiki/),
[svn](http://subversion.tigris.org/), [trac](http://trac.edgewall.org/),
and open discussion of any other source code management programs not yet
mentioned that deserve recognition.
