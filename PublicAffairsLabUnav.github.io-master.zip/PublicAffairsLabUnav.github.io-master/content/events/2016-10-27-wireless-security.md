---
date: 2016-10-27
title: Wireless Security
speaker: William Osler (LibreWulf)
type: Meeting
---
Most of us use wireless networks every day. But do we really understand the
security implications of flinging packets over the air?

Join us this Thursday, October 26 2016 as William Osler gives a talk covering
the basics of wireless network security, including a demonstration of a fun
attack on legacy wireless encryption standards.
