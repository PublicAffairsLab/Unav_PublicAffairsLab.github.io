---
date: 2013-10-10
title: Security and Encryption
---
This Thursday, 2013/10/10 at 7:00pm in Caldwell Labs 120, The Ohio State Open Source Club will present "Security and Encryption". This talk will consist of different members presenting on a variety of topics in the world of personal encryption and protecting your privacy. If you have an interest in security, or cryptographic systems as they apply computing, this is probably the talk for you.

Laptops are encouraged, but not required, and as always, there will be pizza.
