---
date: 2012-05-12
title: OSC Spring LAN
---
The OSC will be hosting its second LAN of the academic year on May 12th, 2012.

Due to difficulties scheduling, it will start at 2:00PM and run until 11:30PM (ie, 9.5 hours) in the Ohio Union's Interfaith Prayer and Reflection room.  Bring Your Own Computer.
