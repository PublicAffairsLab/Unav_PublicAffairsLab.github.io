---
date: 2016-03-24
title: A Recap of NICAR, and open source in journalism
speaker: Ben Keith
type: Meeting
---

Open Source Club and *Lantern* alumnus Ben keith will talk about open source software in journalism. Topics covered will include notable newsroom teams working in the open, tools available for anyone to use, conferences and training available, and some story ideas from the conference.

This talk will also be a recap of NICAR 2016, and give overviews of some talks given there.

This talk is suitable for all audiences, and journalism students are particularly encouraged to come.

Slides will be available.
