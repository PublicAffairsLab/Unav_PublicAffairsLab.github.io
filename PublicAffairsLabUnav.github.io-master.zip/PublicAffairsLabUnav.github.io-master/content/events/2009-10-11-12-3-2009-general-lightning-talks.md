---
date: 2009-10-11
type: "Meeting"
title: General Lightning Talks
---
On Thursday December 3rd, 2009, we will be hosting another lightning talk session that will be compromised of subjects coming from all areas. Lightning talks will consist of several different presentations by different presenters over the course of the meeting time. We will put more info on here about how long the meeting will last and how many presentations there will be once we get more info on who wants to present on what topics.

Here are the topics that have been picked thus far:

*   LaTeX
*   Wifi Auditing
*   DD-WRT Router Firmware
*   iptables

Here are some suggested topics that you could possibly volunteer for:

*   Screen
*   Vim
*   SSH and SSHd config
*   Version Control
*   Overclocking
*   Regular Expressions
*   IRC
*   Any other cool stuff you can come up with

Email Alek Rollyson at rollyson dot 3 at osu dot edu if you are interested in giving a short lightning talk.
