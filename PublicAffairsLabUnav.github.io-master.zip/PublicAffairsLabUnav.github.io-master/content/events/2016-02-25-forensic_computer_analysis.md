---
date: 2016-02-25
title: Forensic Data Analysis
speaker: Matt Curtin
type: Meeting
---

Thursday, 2016/02/25 at 7:00pm in Caldwell Labs 120

This week Matt Curtin will present on forensic data analysis. This will focus on the use of technology in legal cases. Matt Curtin, and his company Interhack Corporation, has addressed courts on the topics of wiretapping, data breaches, and more. Matt Curtin will address the merits of opensource software in forensic data analysis in court rooms in order to reach a resolution that may be much more controversial when using proprietary software.
