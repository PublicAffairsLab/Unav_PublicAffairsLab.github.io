---
date: 2007-01-25
type: "Meeting"
title: 'Meetings: Winter 2007'
---
We are meeting Tuesday evenings this quarter at 7:00pm in Dreese Labs room 480.
Meetings generally last about an hour and are always open to the public
including nonmembers and nonstudents. For people arriving from off campus, pay
parking is available in the Tuttle Park Place Parking Garage, located adjacent
to Dreese Labs. Please refer the OSU map for directions: [osu.edu/map](http://www.osu.edu/map/).

- 01/09/2007 - [Up and Blogging with Wordpress in 5 Minutes (Alex Lingo)](/announcements/2007/01/08/up-and-blogging-with-wordpress-in-5-minutes/)
- 01/16/2007 - Contributing to Open Source (Paul Betts)
- 01/23/2007 - Free Piza Chat Fest
- 01/30/2007 - Impress your Friends with LaTeX (Jim Dinan)
- 02/06/2007 - Cancelled (Snow)
- 02/13/2007 - Cancelled (Snow .. again?!)
- 02/20/2007 - Informal Meeting
- 02/27/2007 - Rockbox on the Gigabeat (Alex)
- 03/06/2007 - GPL V3 (Farhad Salehi)
