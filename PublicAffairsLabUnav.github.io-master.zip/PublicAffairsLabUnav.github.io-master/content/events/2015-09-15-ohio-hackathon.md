---
date: 2015-09-15
title: OHI/O 2015 Hackathon
speaker: OSC
type: Volunteer
---

The 2015 OHI/O Hackathon is fast approaching. [Register now](http://hack.osu.edu/).
