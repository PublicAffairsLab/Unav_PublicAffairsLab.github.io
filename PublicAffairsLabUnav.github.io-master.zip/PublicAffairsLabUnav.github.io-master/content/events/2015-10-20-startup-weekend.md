---
date: 2015-10-20
title: Startup Weekend
speaker: CoverMyMeds
type: Convention
---

Startup Weekend is November 20th. [Learn More](http://www.up.co/communities/usa/columbus/startup-weekend/7362).

Tickets are $100 however if you [email us](mailto:info@opensource.osu.edu) we can provide you with a discount code to reduce the ticket price to $35.
